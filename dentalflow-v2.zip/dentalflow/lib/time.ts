/**
 * Time helpers that work in the clinic's time zone (not the server's or the
 * browser's), using only Intl — no date library needed.
 */
import type { Lang } from './i18n';

interface ZonedParts { y: number; m: number; d: number; hour: number; minute: number; weekday: number }

const WEEKDAYS: Record<string, number> = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
const partsCache = new Map<string, Intl.DateTimeFormat>();

export function zonedParts(date: Date, timeZone: string): ZonedParts {
  let f = partsCache.get(timeZone);
  if (!f) {
    f = new Intl.DateTimeFormat('en-US', {
      timeZone, hourCycle: 'h23', year: 'numeric', month: 'numeric', day: 'numeric',
      hour: 'numeric', minute: 'numeric', weekday: 'short',
    });
    partsCache.set(timeZone, f);
  }
  const p: Record<string, string> = {};
  for (const x of f.formatToParts(date)) p[x.type] = x.value;
  return {
    y: +p.year, m: +p.month, d: +p.day,
    hour: +p.hour % 24, minute: +p.minute,
    weekday: WEEKDAYS[p.weekday] ?? 0,
  };
}

/** Minutes since midnight in the clinic's time zone. */
export function minutesOfDay(date: Date | string, timeZone: string): number {
  const p = zonedParts(new Date(date), timeZone);
  return p.hour * 60 + p.minute;
}

/** The UTC instant for a wall-clock time in a time zone. */
export function zonedTime(y: number, m: number, d: number, hour: number, minute: number, timeZone: string): Date {
  const guess = Date.UTC(y, m - 1, d, hour, minute);
  const offsetAt = (t: number) => {
    const p = zonedParts(new Date(t), timeZone);
    return Date.UTC(p.y, p.m - 1, p.d, p.hour, p.minute) - t;
  };
  let t = guess - offsetAt(guess);
  t = guess - offsetAt(t); // second pass handles DST edges
  return new Date(t);
}

export function sameDay(a: Date | string, b: Date | string, timeZone: string): boolean {
  const x = zonedParts(new Date(a), timeZone), y = zonedParts(new Date(b), timeZone);
  return x.y === y.y && x.m === y.m && x.d === y.d;
}

const pad2 = (n: number) => String(n).padStart(2, '0');

/** 640 → "10:40" */
export const fmtMinutes = (min: number) => `${pad2(Math.floor(min / 60) % 24)}:${pad2(Math.floor(min) % 60)}`;

/** 8.5 → "08:30" */
export const fmtHour = (h: number) => fmtMinutes(Math.round(h * 60));

export const fmtClock = (date: Date | string, timeZone: string) => fmtMinutes(minutesOfDay(date, timeZone));

/** "Tuesday, 12 May 2026" / "Martes, 12 de mayo de 2026" */
export function fmtLongDate(date: Date | string, lang: Lang, timeZone: string): string {
  const s = new Intl.DateTimeFormat(lang === 'es' ? 'es-ES' : 'en-GB', {
    timeZone, weekday: 'long', day: 'numeric', month: 'long', year: 'numeric',
  }).format(new Date(date));
  return s.charAt(0).toUpperCase() + s.slice(1);
}
