/**
 * Waiting-room rules (same behaviour as the v6 prototype), as pure functions
 * so they can be unit-tested and reused by the Queue module.
 */
import { onShift, type ClinicSettings } from './clinic';
import type { QueueEntry } from './data/types';
import { zonedParts } from './time';

export const turnLabel = (no: number) => `A-${String(no).padStart(2, '0')}`;

export const minutesBetween = (from: string | Date, to: string | Date) =>
  Math.max(0, Math.round((new Date(to).getTime() - new Date(from).getTime()) / 60000));

export const waitingList = (q: QueueEntry[]) => q.filter((e) => e.status === 'Waiting').sort((a, b) => a.no - b.no);
export const inChair = (q: QueueEntry[]) => q.filter((e) => e.status === 'In chair');

/** Minutes waited: still running while waiting, frozen once called. */
export const waitMinutes = (e: QueueEntry, now: Date) =>
  e.status === 'Waiting' ? minutesBetween(e.arrivedAt, now) : e.calledAt ? minutesBetween(e.arrivedAt, e.calledAt) : 0;

export const averageWait = (entries: QueueEntry[], now: Date) =>
  entries.length ? Math.round(entries.reduce((s, e) => s + waitMinutes(e, now), 0) / entries.length) : 0;

/** Wait severity used for colour + icon (never colour alone). */
export const waitLevel = (min: number): 'ok' | 'warn' | 'bad' => (min >= 35 ? 'bad' : min >= 20 ? 'warn' : 'ok');

export const freeChair = (q: QueueEntry[], clinic: ClinicSettings) =>
  clinic.chairs.find((c) => !inChair(q).some((e) => e.chair === c)) ?? null;

export const dentistBusy = (q: QueueEntry[], dentist: string) => inChair(q).some((e) => e.dentist === dentist);

export function dentistFreeNow(q: QueueEntry[], dentist: string, clinic: ClinicSettings, now: Date) {
  const p = zonedParts(now, clinic.timeZone);
  return !dentistBusy(q, dentist) && onShift(clinic, dentist, p.weekday, p.hour * 60 + p.minute);
}

/** Who can see this patient right now: the requested dentist, or the first free one for "any". */
export function pickDentist(e: QueueEntry, q: QueueEntry[], clinic: ClinicSettings, now: Date): string | null {
  if (e.dentist === 'any') return clinic.dentists.find((d) => dentistFreeNow(q, d, clinic, now)) ?? null;
  return dentistFreeNow(q, e.dentist, clinic, now) ? e.dentist : null;
}

/** A patient waiting 10+ min for a busy dentist while another dentist is free. */
export function stuckSuggestion(q: QueueEntry[], clinic: ClinicSettings, now: Date) {
  for (const e of waitingList(q)) {
    if (e.dentist !== 'any' && dentistBusy(q, e.dentist) && waitMinutes(e, now) >= 10) {
      const alt = clinic.dentists.find((d) => d !== e.dentist && dentistFreeNow(q, d, clinic, now));
      if (alt) return { entry: e, alt };
    }
  }
  return null;
}
