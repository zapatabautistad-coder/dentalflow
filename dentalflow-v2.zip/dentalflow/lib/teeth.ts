/** FDI order as seen from the front: upper 18→11 | 21→28, lower 48→41 | 31→38. */
export const UPPER = [18, 17, 16, 15, 14, 13, 12, 11, 21, 22, 23, 24, 25, 26, 27, 28];
export const LOWER = [48, 47, 46, 45, 44, 43, 42, 41, 31, 32, 33, 34, 35, 36, 37, 38];

/** FDI number → the clinic's numbering. Universal (US): upper 18→28 = 1→16, lower 38→48 = 17→32. */
export function toothLabel(fdi: number, numbering: 'FDI' | 'Universal'): number {
  if (numbering !== 'Universal') return fdi;
  const u = UPPER.indexOf(fdi);
  return u >= 0 ? u + 1 : 32 - LOWER.indexOf(fdi);
}

/** Parses "36, 37" (in the clinic's numbering) back to FDI numbers; ignores anything invalid. */
export function parseTeeth(input: string, numbering: 'FDI' | 'Universal'): number[] {
  const all = [...UPPER, ...LOWER];
  const out = new Set<number>();
  for (const part of input.split(/[\s,;]+/)) {
    const n = Number(part);
    if (!Number.isInteger(n)) continue;
    const fdi = all.find((x) => toothLabel(x, numbering) === n);
    if (fdi) out.add(fdi);
  }
  return [...out];
}
