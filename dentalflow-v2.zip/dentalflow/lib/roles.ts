/**
 * Modules and role-based access (v6 matrix + Settings for Admin):
 * - Dentist: clinical modules, edits the dental chart, writes notes and prescriptions, no money.
 * - Front desk: + billing; dental chart read-only.
 * - Admin: everything, including analytics and clinic settings.
 */
export type ModuleKey =
  | 'dashboard' | 'queue' | 'patients' | 'odontogram' | 'appointments'
  | 'schedules' | 'treatments' | 'billing' | 'analytics' | 'settings';

export const MODULES: { key: ModuleKey; href: string }[] = [
  { key: 'dashboard', href: '/' },
  { key: 'queue', href: '/queue' },
  { key: 'patients', href: '/patients' },
  { key: 'odontogram', href: '/odontogram' },
  { key: 'appointments', href: '/appointments' },
  { key: 'schedules', href: '/schedules' },
  { key: 'treatments', href: '/treatments' },
  { key: 'billing', href: '/billing' },
  { key: 'analytics', href: '/analytics' },
  { key: 'settings', href: '/settings' },
];

export type Role = 'doctor' | 'reception' | 'admin';
export type Permission = 'clinical' | 'billing' | 'finance' | 'schedEdit';

const CORE: ModuleKey[] = ['dashboard', 'queue', 'patients', 'odontogram', 'appointments', 'schedules', 'treatments'];

export const ROLES: Record<Role, { modules: ModuleKey[]; perms: Permission[] }> = {
  doctor: { modules: CORE, perms: ['clinical'] },
  reception: { modules: [...CORE, 'billing'], perms: ['billing'] },
  admin: { modules: [...CORE, 'billing', 'analytics', 'settings'], perms: ['billing', 'finance', 'schedEdit'] },
};

export const ROLE_KEYS = Object.keys(ROLES) as Role[];

export const isRole = (v: unknown): v is Role => typeof v === 'string' && v in ROLES;
export const canView = (role: Role, m: ModuleKey) => ROLES[role].modules.includes(m);
export const can = (role: Role, p: Permission) => ROLES[role].perms.includes(p);
export const rolesWith = (m: ModuleKey) => ROLE_KEYS.filter((r) => canView(r, m));

export function moduleFromPath(pathname: string): ModuleKey | null {
  if (pathname === '/') return 'dashboard';
  const seg = pathname.split('/')[1];
  return MODULES.find((m) => m.key === seg)?.key ?? null;
}
