/**
 * Clinical rules shown as reminders to the dentist. They never block care:
 * they point at something to verify. Doses are editable defaults.
 */
import type { Lang } from './i18n';
import type { Appointment, MedicalAlert, Patient, QueueEntry } from './data/types';
import { minutesBetween } from './queue';

type L2 = readonly [en: string, es: string];
const pick = (lang: Lang, v: L2) => v[lang === 'es' ? 1 : 0];

export const MEDICAL_ALERTS: Record<MedicalAlert, L2> = {
  anticoagulant: ['Anticoagulated', 'Anticoagulado'],
  diabetes: ['Diabetes', 'Diabetes'],
  hypertension: ['Hypertension', 'Hipertensión'],
  pregnancy: ['Pregnancy', 'Embarazo'],
  cardiac: ['Heart condition', 'Cardiopatía'],
  bisphosphonates: ['Bisphosphonates', 'Bifosfonatos'],
};
export const alertLabel = (lang: Lang, a: MedicalAlert) => pick(lang, MEDICAL_ALERTS[a]);

/* ---------- prescriptions ---------- */

type DrugClass = 'penicillin' | 'nsaid';

export interface Drug {
  id: string;
  name: L2;
  directions: L2;
  classes: DrugClass[];
}

export const DRUGS: Drug[] = [
  { id: 'amox', name: ['Amoxicillin 500 mg', 'Amoxicilina 500 mg'], directions: ['1 capsule every 8 h for 7 days', '1 cápsula cada 8 h por 7 días'], classes: ['penicillin'] },
  { id: 'clinda', name: ['Clindamycin 300 mg', 'Clindamicina 300 mg'], directions: ['1 capsule every 8 h for 7 days', '1 cápsula cada 8 h por 7 días'], classes: [] },
  { id: 'ibu', name: ['Ibuprofen 400 mg', 'Ibuprofeno 400 mg'], directions: ['1 tablet every 8 h for 3 days, with food', '1 tableta cada 8 h por 3 días, con alimentos'], classes: ['nsaid'] },
  { id: 'para', name: ['Paracetamol 500 mg', 'Paracetamol 500 mg'], directions: ['1–2 tablets every 8 h if there is pain', '1–2 tabletas cada 8 h si hay dolor'], classes: [] },
  { id: 'chx', name: ['Chlorhexidine 0.12% rinse', 'Clorhexidina 0.12 % enjuague'], directions: ['Rinse with 15 ml every 12 h for 7 days', 'Enjuagar con 15 ml cada 12 h por 7 días'], classes: [] },
];

export const drugName = (lang: Lang, d: Drug) => pick(lang, d.name);
export const drugDirections = (lang: Lang, d: Drug) => pick(lang, d.directions);

export type RxWarning = 'allergyPenicillin' | 'allergyNsaid' | 'anticoagNsaid' | 'pregnancyNsaid';

/** Checks the chosen drugs against the patient's allergies and medical alerts. */
export function prescriptionWarnings(patient: Patient, drugs: Drug[]): { drug: Drug; warning: RxWarning }[] {
  const allergy = (patient.allergy ?? '').toLowerCase();
  const out: { drug: Drug; warning: RxWarning }[] = [];
  for (const d of drugs) {
    if (d.classes.includes('penicillin') && /penicil/.test(allergy)) out.push({ drug: d, warning: 'allergyPenicillin' });
    if (d.classes.includes('nsaid')) {
      if (/ibuprof|nsaid|aine|aspirin|aspirina|diclofen|naprox/.test(allergy)) out.push({ drug: d, warning: 'allergyNsaid' });
      if (patient.medicalAlerts.includes('anticoagulant')) out.push({ drug: d, warning: 'anticoagNsaid' });
      if (patient.medicalAlerts.includes('pregnancy')) out.push({ drug: d, warning: 'pregnancyNsaid' });
    }
  }
  return out;
}

/* ---------- schedule rules ---------- */

/** A patient still in the chair past the booked end time, and the dentist's next booking. */
export function chairDelays(queue: QueueEntry[], today: Appointment[], now: Date) {
  const out: { entry: QueueEntry; appt: Appointment; overMin: number; next: Appointment | undefined }[] = [];
  for (const e of queue) {
    if (e.status !== 'In chair' || !e.appointmentId) continue;
    const appt = today.find((a) => a.id === e.appointmentId);
    if (!appt) continue;
    const end = new Date(new Date(appt.startsAt).getTime() + appt.durationMin * 60000);
    const overMin = now > end ? minutesBetween(end, now) : 0;
    if (overMin < 10) continue;
    const next = today
      .filter((a) => a.dentist === e.dentist && a.id !== appt.id && new Date(a.startsAt) > now)
      .sort((a, b) => a.startsAt.localeCompare(b.startsAt))[0];
    out.push({ entry: e, appt, overMin, next });
  }
  return out;
}

/** Patients whose last cleaning is more than six months old. */
export const recallsDue = (patients: Patient[], now: Date) =>
  patients.filter((p) => p.lastCleaning && minutesBetween(p.lastCleaning, now) > 182 * 24 * 60);

/* ---------- WhatsApp ---------- */

/** Opens WhatsApp (web or app) with a ready reminder — no API needed. */
export function whatsappLink(phone: string, text: string): string {
  return `https://wa.me/${phone.replace(/\D/g, '')}?text=${encodeURIComponent(text)}`;
}
