import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { cache } from 'react';
import { COOKIES } from './cookies';
import { isSampleMode } from './data';
import { isRole, type Role } from './roles';

export interface SessionUser {
  /** Display name; null for shared role accounts (e.g. the front-desk login). */
  name: string | null;
  initials: string;
  role: Role;
}

/** Sample staff accounts — no invented people: the dentist exists in the clinic data, the others are role accounts. */
export const SAMPLE_USERS: Record<Role, SessionUser> = {
  doctor: { name: 'Dr. Alvarez', initials: 'DA', role: 'doctor' },
  reception: { name: null, initials: 'RC', role: 'reception' },
  admin: { name: null, initials: 'AD', role: 'admin' },
};

/**
 * The signed-in user, or null. The role always comes from here — never from a UI switch.
 * Next step: Supabase Auth + a `staff` table with the role per clinic.
 */
export const getSession = cache(async (): Promise<SessionUser | null> => {
  if (!isSampleMode()) throw new Error('Authentication is not connected yet.');
  const r = (await cookies()).get(COOKIES.session)?.value;
  return isRole(r) ? SAMPLE_USERS[r] : null;
});

/** For pages behind login: returns the user or sends them to /login. */
export async function requireSession(): Promise<SessionUser> {
  const user = await getSession();
  if (!user) redirect('/login');
  return user;
}
