/**
 * Country profiles (same as the v6 demo).
 * Base amounts are stored in USD; each profile converts with a fixed demo rate.
 * Tax rules summarise public guidance for dental services — a real deployment
 * must be validated with a local accountant.
 */
import type { Lang } from './i18n';

type L2 = readonly [en: string, es: string];

export type CountryCode = 'intl' | 'us' | 'do' | 'mx' | 'co' | 'es' | 'uk';

export interface CountryProfile {
  name: L2;
  currency: string;
  /** Demo exchange rate from USD. */
  fx: number;
  locale: string;
  prefix: string;
  suffix: string;
  /** Tooth numbering system. */
  numbering: 'FDI' | 'Universal';
  taxName: L2;
  /** VAT rate applied to purely cosmetic treatments, or null when all dental care is exempt. */
  cosmeticRate: number | null;
  taxRule: L2;
  docLabel: L2;
  docNumber: (seq: number, business: boolean) => string;
  taxIdLabel: L2;
  insuranceLabel: L2;
}

export const COUNTRIES: Record<CountryCode, CountryProfile> = {
  intl: {
    name: ['International (generic)', 'Internacional (genérico)'],
    currency: 'USD', fx: 1, locale: 'en-US', prefix: '$', suffix: '', numbering: 'FDI',
    taxName: ['Tax', 'Impuesto'], cosmeticRate: null,
    taxRule: ['Health-service tax rules differ by country — pick a country to apply its rules.', 'Las reglas fiscales de los servicios de salud cambian según el país: elige uno para aplicar sus reglas.'],
    docLabel: ['Invoice #', 'N.º factura'], docNumber: (s) => `INV-${s}`,
    taxIdLabel: ['Tax ID', 'ID fiscal'], insuranceLabel: ['Insurance', 'Seguro'],
  },
  us: {
    name: ['United States', 'Estados Unidos'],
    currency: 'USD', fx: 1, locale: 'en-US', prefix: '$', suffix: '', numbering: 'Universal',
    taxName: ['Sales tax', 'Sales tax'], cosmeticRate: null,
    taxRule: ['Dental services are generally not subject to sales tax — confirm the rules of each state.', 'Los servicios dentales en general no pagan sales tax; hay que confirmar las reglas de cada estado.'],
    docLabel: ['Statement #', 'N.º estado de cuenta'], docNumber: (s) => `STM-${s}`,
    taxIdLabel: ['EIN', 'EIN'], insuranceLabel: ['Dental insurance', 'Seguro dental'],
  },
  do: {
    name: ['Dominican Republic', 'República Dominicana'],
    currency: 'DOP', fx: 60, locale: 'en-US', prefix: 'RD$', suffix: '', numbering: 'FDI',
    taxName: ['ITBIS', 'ITBIS'], cosmeticRate: null,
    taxRule: ['Dental services are health services and are ITBIS-exempt (Law 11-92 art. 344, amended by Law 253-12).', 'Los servicios odontológicos son servicios de salud y están exentos de ITBIS (Ley 11-92 art. 344, mod. Ley 253-12).'],
    docLabel: ['e-NCF', 'e-NCF'], docNumber: (s, b) => `${b ? 'E31' : 'E32'}${String(s).padStart(10, '0')}`,
    taxIdLabel: ['RNC', 'RNC'], insuranceLabel: ['Health insurer (ARS)', 'Seguro (ARS)'],
  },
  mx: {
    name: ['Mexico', 'México'],
    currency: 'MXN', fx: 18, locale: 'es-MX', prefix: '$', suffix: ' MXN', numbering: 'FDI',
    taxName: ['IVA', 'IVA'], cosmeticRate: null,
    taxRule: ['Medical and dental services are VAT-exempt (IVA Law art. 15).', 'Los servicios médicos y dentales están exentos de IVA (LIVA art. 15).'],
    docLabel: ['CFDI folio', 'Folio CFDI'], docNumber: (s) => `A-${s}`,
    taxIdLabel: ['RFC', 'RFC'], insuranceLabel: ['Insurer', 'Aseguradora'],
  },
  co: {
    name: ['Colombia', 'Colombia'],
    currency: 'COP', fx: 4000, locale: 'es-CO', prefix: '$', suffix: ' COP', numbering: 'FDI',
    taxName: ['IVA', 'IVA'], cosmeticRate: null,
    taxRule: ['Health services are excluded from VAT (Tax Statute art. 476).', 'Los servicios de salud están excluidos de IVA (Estatuto Tributario art. 476).'],
    docLabel: ['e-invoice #', 'N.º factura electrónica'], docNumber: (s) => `FE-${s}`,
    taxIdLabel: ['NIT', 'NIT'], insuranceLabel: ['Health insurer (EPS)', 'EPS / aseguradora'],
  },
  es: {
    name: ['Spain', 'España'],
    currency: 'EUR', fx: 0.92, locale: 'es-ES', prefix: '', suffix: ' €', numbering: 'FDI',
    taxName: ['VAT', 'IVA'], cosmeticRate: 0.21,
    taxRule: ['Healthcare by dentists is VAT-exempt (Law 37/1992 art. 20); purely cosmetic treatments are taxed at 21%.', 'La asistencia sanitaria de dentistas está exenta de IVA (Ley 37/1992 art. 20); los tratamientos puramente estéticos tributan al 21%.'],
    docLabel: ['Invoice #', 'N.º factura'], docNumber: (s) => `2026-A-${s}`,
    taxIdLabel: ['NIF', 'NIF'], insuranceLabel: ['Insurer (mutua)', 'Mutua / aseguradora'],
  },
  uk: {
    name: ['United Kingdom', 'Reino Unido'],
    currency: 'GBP', fx: 0.78, locale: 'en-GB', prefix: '£', suffix: '', numbering: 'FDI',
    taxName: ['VAT', 'IVA'], cosmeticRate: 0.2,
    taxRule: ['Dental care by registered professionals is VAT-exempt; purely cosmetic treatments (e.g. whitening) are standard-rated at 20%.', 'La atención dental de profesionales registrados está exenta de IVA; los tratamientos puramente estéticos (p. ej. blanqueamiento) pagan el 20%.'],
    docLabel: ['Invoice #', 'N.º factura'], docNumber: (s) => `INV-${s}`,
    taxIdLabel: ['VAT reg. no.', 'N.º de IVA'], insuranceLabel: ['NHS / private plan', 'NHS / plan privado'],
  },
};

export const COUNTRY_CODES = Object.keys(COUNTRIES) as CountryCode[];

export const isCountryCode = (v: unknown): v is CountryCode =>
  typeof v === 'string' && v in COUNTRIES;

export const l2 = (lang: Lang, pair: L2) => pair[lang === 'es' ? 1 : 0];

/** Initial country from the browser time zone (same rule as v6). */
export function countryFromTimeZone(tz: string): CountryCode {
  const map: Record<string, CountryCode> = {
    'America/Santo_Domingo': 'do',
    'America/Mexico_City': 'mx', 'America/Monterrey': 'mx', 'America/Cancun': 'mx', 'America/Tijuana': 'mx',
    'America/Bogota': 'co', 'Europe/Madrid': 'es', 'Atlantic/Canary': 'es', 'Europe/London': 'uk',
  };
  if (map[tz]) return map[tz];
  if (/^America\/(New_York|Chicago|Denver|Los_Angeles|Phoenix|Anchorage|Detroit|Indiana|Kentucky|Boise)/.test(tz) || tz === 'Pacific/Honolulu') return 'us';
  return 'intl';
}
