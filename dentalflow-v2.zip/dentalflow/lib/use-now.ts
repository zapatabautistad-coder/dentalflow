'use client';

import { useEffect, useState } from 'react';

/**
 * Current time for the UI. Starts from the server's snapshot time (so the
 * first client render matches the server) and then runs in real time.
 */
export function useNow(serverNowIso: string, everyMs = 15_000): Date {
  const [now, setNow] = useState(() => new Date(serverNowIso));
  useEffect(() => {
    const base = new Date(serverNowIso).getTime();
    const t0 = Date.now();
    setNow(new Date(base));
    const id = setInterval(() => setNow(new Date(base + Date.now() - t0)), everyMs);
    return () => clearInterval(id);
  }, [serverNowIso, everyMs]);
  return now;
}
