import { cookies, headers } from 'next/headers';
import { cache } from 'react';
import { COOKIES } from './cookies';
import type { Lang } from './i18n';

/** Saved choice first, then the browser language; Spanish by default. */
export const resolveLang = cache(async (): Promise<Lang> => {
  const saved = (await cookies()).get(COOKIES.lang)?.value;
  if (saved === 'en' || saved === 'es') return saved;
  const accept = (await headers()).get('accept-language') ?? '';
  return /^en\b/i.test(accept.trim()) ? 'en' : 'es';
});
