import type { CountryCode } from './countries';

/** [open, close] in hours (e.g. [8, 18]); null = closed / day off. Index = JS weekday (0 Sunday … 6 Saturday). */
export type DayHours = readonly [number, number] | null;
export type WeekHours = readonly [DayHours, DayHours, DayHours, DayHours, DayHours, DayHours, DayHours];

/** Clinic-level settings. They will live in a `clinics` table and be edited by Admin in Settings. */
export interface ClinicSettings {
  id: string;
  name: string;
  /** City shown next to the clinic name. */
  city: string;
  country: CountryCode;
  /** IANA time zone used for every date and time the clinic sees. */
  timeZone: string;
  hours: WeekHours;
  chairs: string[];
  dentists: string[];
  shifts: Record<string, WeekHours>;
}

export function hoursOn(clinic: ClinicSettings, weekday: number): DayHours {
  return clinic.hours[weekday] ?? null;
}

export function onShift(clinic: ClinicSettings, dentist: string, weekday: number, minuteOfDay: number): boolean {
  const s = clinic.shifts[dentist]?.[weekday];
  const h = minuteOfDay / 60;
  return !!s && h >= s[0] && h < s[1];
}
