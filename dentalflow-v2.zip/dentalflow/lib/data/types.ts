/**
 * Domain types. They mirror the tables planned for Supabase, so the sample
 * data in ./sample.ts can later be swapped for real queries without touching
 * the UI components.
 */

export type AppointmentStatus = 'Confirmed' | 'Pending' | 'In progress' | 'Completed' | 'Missed';
export type QueueStatus = 'Waiting' | 'In chair' | 'Done' | 'No-show';
export type InvoiceStatus = 'Pending' | 'Paid' | 'Partially paid' | 'Overdue';
export type ToothState = 'healthy' | 'caries' | 'filled' | 'endo' | 'crown' | 'missing';

/** Conditions the dentist must see before anaesthesia, extractions or prescribing. */
export type MedicalAlert = 'anticoagulant' | 'diabetes' | 'hypertension' | 'pregnancy' | 'cardiac' | 'bisphosphonates';
export type LabStatus = 'sent' | 'received';
export type ConsentStatus = 'signed' | 'pending';

export interface Patient {
  id: string;
  initials: string;
  name: string;
  age: number;
  phone: string;
  insurance: string;
  /** Uploaded photo; initials are shown when missing. */
  photoUrl: string | null;
  allergy: string | null;
  medicalAlerts: MedicalAlert[];
  /** Number of radiographs on file. */
  xrays: number;
  /** ISO date, or null for a new patient. */
  lastVisit: string | null;
  /** ISO date of the last cleaning — drives recall reminders. */
  lastCleaning: string | null;
  lifetimeValueUsd: number;
  outstandingUsd: number;
}

export interface Appointment {
  id: string;
  patientId: string;
  /** ISO timestamp. */
  startsAt: string;
  durationMin: number;
  treatment: string;
  /** Teeth involved, FDI notation (shown in the clinic's numbering). */
  teeth: number[];
  chair: string;
  dentist: string;
  status: AppointmentStatus;
  /** Lab work needed for this visit (crown, guide, prosthesis…). */
  lab: { item: string; lab: string; status: LabStatus } | null;
  /** Informed consent; null when the procedure does not require one. */
  consent: ConsentStatus | null;
}

export interface QueueEntry {
  id: string;
  /** Turn number shown as A-01, A-02… */
  no: number;
  patientId: string;
  appointmentId: string | null;
  /** ISO timestamps. */
  arrivedAt: string;
  calledAt?: string;
  finishedAt?: string;
  /** A dentist name, or 'any' for walk-ins without preference. */
  dentist: string;
  chair?: string;
  status: QueueStatus;
}

export interface Invoice {
  id: string;
  seq: number;
  patientId: string;
  treatment: string;
  amountUsd: number;
  /** ISO date. */
  due: string;
  status: InvoiceStatus;
  /** Business client (e.g. E31 in the Dominican Republic). */
  business?: boolean;
}

export interface PlanStage {
  n: number;
  description: string;
  /** ISO date, or null when not scheduled yet. */
  date: string | null;
  state: 'done' | 'alert' | 'future';
}

export interface TreatmentPlan {
  id: string;
  patientId: string;
  name: string;
  dentist: string;
  /** Tooth in FDI notation. */
  tooth: number;
  totalUsd: number;
  paidUsd: number;
  stages: PlanStage[];
}

export interface ClinicalNote {
  id: string;
  patientId: string;
  author: string;
  /** ISO timestamp. */
  createdAt: string;
  procedure: string;
  teeth: number[];
  text: string;
}

export interface Prescription {
  id: string;
  patientId: string;
  author: string;
  createdAt: string;
  items: { drug: string; directions: string }[];
}

/** Per patient, FDI tooth number → state. Missing keys mean healthy. */
export type DentalChart = Record<string, Partial<Record<number, ToothState>>>;

export interface ClinicSnapshot {
  /** Server time when the snapshot was taken (ISO). The client clock starts from here. */
  now: string;
  /** True while the app runs on sample data instead of the clinic's database. */
  sample: boolean;
  patients: Patient[];
  appointments: Appointment[];
  queue: QueueEntry[];
  invoices: Invoice[];
  plans: TreatmentPlan[];
  teeth: DentalChart;
  notes: ClinicalNote[];
  prescriptions: Prescription[];
}
