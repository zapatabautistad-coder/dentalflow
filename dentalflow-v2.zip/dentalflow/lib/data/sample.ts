import type { ClinicSettings } from '../clinic';
import type { CountryCode } from '../countries';
import { zonedParts, zonedTime } from '../time';
import type { ClinicSnapshot } from './types';

/**
 * Sample data used until the clinic's database (Supabase) is connected.
 * Same people as the v6 prototype, the Figma file and the case study
 * (Bright Smile Dental, Maria Restrepo, Dr. Alvarez…), but every date and
 * time is built around the real current date so the dashboard is coherent
 * whenever it is opened.
 */

const ALL_DAYS = [8, 18] as const;

/** Where the sample clinic sits for each test country. */
const LOCATION: Record<CountryCode, { city: string; timeZone: string }> = {
  intl: { city: 'Santo Domingo', timeZone: 'America/Santo_Domingo' },
  do: { city: 'Santo Domingo, RD', timeZone: 'America/Santo_Domingo' },
  us: { city: 'Miami, FL', timeZone: 'America/New_York' },
  mx: { city: 'Ciudad de México', timeZone: 'America/Mexico_City' },
  co: { city: 'Bogotá', timeZone: 'America/Bogota' },
  es: { city: 'Madrid', timeZone: 'Europe/Madrid' },
  uk: { city: 'London', timeZone: 'Europe/London' },
};

export function sampleClinic(country: CountryCode = 'do'): ClinicSettings {
  return {
    id: 'sample',
    name: 'Bright Smile Dental',
    city: LOCATION[country].city,
    country,
    timeZone: LOCATION[country].timeZone,
    hours: [ALL_DAYS, ALL_DAYS, ALL_DAYS, ALL_DAYS, ALL_DAYS, ALL_DAYS, ALL_DAYS],
    chairs: ['Chair 1', 'Chair 2'],
    dentists: ['Dr. Alvarez', 'Dr. Mensah', 'Dr. Okafor'],
    shifts: {
      'Dr. Alvarez': [ALL_DAYS, ALL_DAYS, ALL_DAYS, ALL_DAYS, ALL_DAYS, ALL_DAYS, ALL_DAYS],
      'Dr. Mensah': [ALL_DAYS, ALL_DAYS, ALL_DAYS, ALL_DAYS, ALL_DAYS, ALL_DAYS, ALL_DAYS],
      'Dr. Okafor': [null, null, [8, 17], null, [8, 17], null, [8, 17]],
    },
  };
}

export function sampleSnapshot(clinic: ClinicSettings, realNow = new Date()): ClinicSnapshot {
  const tz = clinic.timeZone;
  const today = zonedParts(realNow, tz);
  const nowMin = today.hour * 60 + today.minute;

  /* Keep the sample inside a working day: use the real time when it falls in
     10:00–15:30, otherwise pin the clock to 10:40 (it then runs in real time). */
  const anchorMin = nowMin >= 600 && nowMin <= 930 ? nowMin : 640;

  /** Calendar day `dayOffset` days from today, in the clinic's time zone. */
  const cal = (dayOffset: number) => new Date(Date.UTC(today.y, today.m - 1, today.d + dayOffset));
  const iso = (dayOffset: number, minuteOfDay: number) => {
    const d = cal(dayOffset);
    return zonedTime(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate(), Math.floor(minuteOfDay / 60), minuteOfDay % 60, tz).toISOString();
  };
  const day = (dayOffset: number) => cal(dayOffset).toISOString().slice(0, 10);
  const q15 = (m: number, up = false) => (up ? Math.ceil(m / 15) : Math.round(m / 15)) * 15;
  const rel = (delta: number) => iso(0, anchorMin + delta);

  return {
    now: rel(0),
    sample: true,
    patients: [
      { id: 'p1', initials: 'MR', name: 'Maria Restrepo', age: 34, phone: '+1 809 555 0142', insurance: 'Humana · Active', photoUrl: null, allergy: 'Penicillin · Latex', medicalAlerts: ['hypertension'], xrays: 4, lastVisit: day(-14), lastCleaning: day(-210), lifetimeValueUsd: 3180, outstandingUsd: 760 },
      { id: 'p2', initials: 'JO', name: 'James Okonkwo', age: 41, phone: '+1 809 555 0198', insurance: 'Self-pay', photoUrl: null, allergy: null, medicalAlerts: [], xrays: 1, lastVisit: day(0), lastCleaning: day(0), lifetimeValueUsd: 1240, outstandingUsd: 0 },
      { id: 'p3', initials: 'LF', name: 'Lucia Fernandez', age: 29, phone: '+1 809 555 0177', insurance: 'MAPFRE · Active', photoUrl: null, allergy: null, medicalAlerts: [], xrays: 2, lastVisit: day(0), lastCleaning: day(-90), lifetimeValueUsd: 2460, outstandingUsd: 420 },
      { id: 'p4', initials: 'AH', name: 'Ahmed Haddad', age: 52, phone: '+1 809 555 0123', insurance: 'Humana · Active', photoUrl: null, allergy: 'Ibuprofen', medicalAlerts: ['anticoagulant', 'hypertension'], xrays: 3, lastVisit: day(-20), lastCleaning: day(-150), lifetimeValueUsd: 80, outstandingUsd: 1120 },
      { id: 'p5', initials: 'SB', name: 'Sofia Bianchi', age: 38, phone: '+1 809 555 0165', insurance: 'Self-pay', photoUrl: null, allergy: null, medicalAlerts: ['pregnancy'], xrays: 0, lastVisit: day(-14), lastCleaning: day(-14), lifetimeValueUsd: 980, outstandingUsd: 0 },
      { id: 'p6', initials: 'DK', name: 'Daniel Kim', age: 45, phone: '+1 809 555 0111', insurance: 'MAPFRE · Lapsed', photoUrl: null, allergy: null, medicalAlerts: ['diabetes'], xrays: 1, lastVisit: day(-40), lastCleaning: day(-400), lifetimeValueUsd: 640, outstandingUsd: 310 },
      { id: 'p7', initials: 'PR', name: 'Priya Raman', age: 27, phone: '+1 809 555 0154', insurance: 'Self-pay', photoUrl: null, allergy: null, medicalAlerts: [], xrays: 1, lastVisit: null, lastCleaning: null, lifetimeValueUsd: 0, outstandingUsd: 0 },
    ],
    appointments: [
      { id: 'a1', patientId: 'p1', startsAt: iso(-1, 510), durationMin: 60, treatment: 'Root canal', teeth: [36], chair: 'Chair 1', dentist: 'Dr. Alvarez', status: 'Completed', lab: null, consent: 'signed' },
      { id: 'a2', patientId: 'p2', startsAt: iso(-1, 600), durationMin: 45, treatment: 'Cleaning', teeth: [], chair: 'Chair 2', dentist: 'Dr. Alvarez', status: 'Completed', lab: null, consent: null },
      { id: 'a3', patientId: 'p6', startsAt: iso(-1, 840), durationMin: 90, treatment: 'Extraction', teeth: [36], chair: 'Chair 1', dentist: 'Dr. Mensah', status: 'Missed', lab: null, consent: 'signed' },
      { id: 'a4', patientId: 'p3', startsAt: iso(0, q15(anchorMin - 100)), durationMin: 60, treatment: 'Crown fitting', teeth: [21], chair: 'Chair 1', dentist: 'Dr. Mensah', status: 'In progress', lab: { item: 'Crown', lab: 'Lab Dental Norte', status: 'received' }, consent: 'signed' },
      { id: 'a5', patientId: 'p4', startsAt: iso(0, q15(anchorMin + 15, true)), durationMin: 45, treatment: 'Consultation', teeth: [], chair: 'Chair 2', dentist: 'Dr. Mensah', status: 'Pending', lab: null, consent: null },
      { id: 'a6', patientId: 'p5', startsAt: iso(0, q15(anchorMin + 140, true)), durationMin: 60, treatment: 'Whitening', teeth: [], chair: 'Chair 1', dentist: 'Dr. Alvarez', status: 'Confirmed', lab: null, consent: 'pending' },
      { id: 'a7', patientId: 'p7', startsAt: iso(1, 510), durationMin: 90, treatment: 'Implant review', teeth: [46], chair: 'Chair 1', dentist: 'Dr. Alvarez', status: 'Pending', lab: { item: 'Surgical guide', lab: 'Lab Dental Norte', status: 'sent' }, consent: 'pending' },
      { id: 'a8', patientId: 'p3', startsAt: iso(2, 570), durationMin: 60, treatment: 'Crown check', teeth: [21], chair: 'Chair 2', dentist: 'Dr. Mensah', status: 'Pending', lab: null, consent: null },
      { id: 'a9', patientId: 'p2', startsAt: iso(3, 510), durationMin: 60, treatment: 'Cleaning', teeth: [], chair: 'Chair 1', dentist: 'Dr. Alvarez', status: 'Confirmed', lab: null, consent: null },
    ],
    queue: [
      { id: 'q1', no: 1, patientId: 'p3', appointmentId: 'a4', arrivedAt: rel(-108), calledAt: rel(-96), dentist: 'Dr. Mensah', chair: 'Chair 1', status: 'In chair' },
      { id: 'q2', no: 2, patientId: 'p2', appointmentId: null, arrivedAt: rel(-85), calledAt: rel(-78), finishedAt: rel(-38), dentist: 'Dr. Alvarez', chair: 'Chair 2', status: 'Done' },
      { id: 'q3', no: 3, patientId: 'p4', appointmentId: 'a5', arrivedAt: rel(-19), dentist: 'Dr. Mensah', status: 'Waiting' },
      { id: 'q4', no: 4, patientId: 'p6', appointmentId: null, arrivedAt: rel(-12), dentist: 'any', status: 'Waiting' },
      { id: 'q5', no: 5, patientId: 'p7', appointmentId: null, arrivedAt: rel(-4), dentist: 'Dr. Alvarez', status: 'Waiting' },
    ],
    invoices: [
      { id: '#1042', seq: 1042, patientId: 'p1', treatment: 'Root canal — stage 2', amountUsd: 620, due: day(8), status: 'Pending' },
      { id: '#1041', seq: 1041, patientId: 'p2', treatment: 'Cleaning & scaling', amountUsd: 140, due: day(6), status: 'Paid' },
      { id: '#1038', seq: 1038, patientId: 'p3', treatment: 'Crown fitting', amountUsd: 980, due: day(3), status: 'Partially paid' },
      { id: '#1034', seq: 1034, patientId: 'p4', treatment: 'Consultation', amountUsd: 80, due: day(-20), status: 'Paid', business: true },
      { id: '#1029', seq: 1029, patientId: 'p6', treatment: 'Extraction', amountUsd: 310, due: day(-40), status: 'Overdue' },
      { id: '#1027', seq: 1027, patientId: 'p5', treatment: 'Whitening', amountUsd: 340, due: day(-14), status: 'Paid' },
      { id: '#1021', seq: 1021, patientId: 'p4', treatment: 'Composite filling', amountUsd: 1040, due: day(-49), status: 'Overdue', business: true },
      { id: '#1018', seq: 1018, patientId: 'p7', treatment: 'Implant consult', amountUsd: 150, due: day(8), status: 'Pending' },
    ],
    plans: [
      {
        id: '0482', patientId: 'p1', name: 'Root canal', dentist: 'Dr. Alvarez', tooth: 36, totalUsd: 1860, paidUsd: 1100,
        stages: [
          { n: 1, description: 'Access & cleaning', date: day(-28), state: 'done' },
          { n: 2, description: 'Canal shaping', date: day(-14), state: 'done' },
          { n: 3, description: 'Filling & seal', date: null, state: 'alert' },
          { n: 4, description: 'Crown placement', date: null, state: 'future' },
        ],
      },
    ],
    teeth: {
      p1: { 18: 'missing', 16: 'caries', 26: 'filled', 36: 'endo', 47: 'crown', 48: 'missing', 25: 'caries' },
      p2: { 17: 'filled', 27: 'filled', 46: 'filled' },
      p3: { 21: 'crown', 11: 'filled', 37: 'caries' },
      p4: { 18: 'missing', 28: 'missing', 38: 'missing', 48: 'missing', 14: 'caries', 36: 'crown', 46: 'endo' },
      p5: {},
      p6: { 24: 'caries', 35: 'caries', 36: 'missing', 45: 'filled' },
      p7: { 16: 'filled' },
    },
    notes: [],
    prescriptions: [],
  };
}
