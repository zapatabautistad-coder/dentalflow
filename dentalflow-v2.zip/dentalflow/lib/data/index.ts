import { cookies } from 'next/headers';
import { cache } from 'react';
import type { ClinicSettings } from '../clinic';
import { COOKIES } from '../cookies';
import { isCountryCode } from '../countries';
import { sampleClinic, sampleSnapshot } from './sample';
import type { ClinicSnapshot } from './types';

/**
 * Single entry point for clinic data. Server-only (uses next/headers).
 *
 * DATA_SOURCE=sample (default) → sample data built around today's date.
 * DATA_SOURCE=supabase        → the clinic's database (next step; not wired yet).
 */
export const DATA_SOURCE = process.env.DATA_SOURCE ?? 'sample';
export const isSampleMode = () => DATA_SOURCE === 'sample';

function notConnected(): never {
  throw new Error(`DATA_SOURCE="${DATA_SOURCE}" is not connected yet. Use DATA_SOURCE=sample until Supabase is wired.`);
}

export const getClinicSettings = cache(async (): Promise<ClinicSettings> => {
  if (!isSampleMode()) notConnected();
  const override = (await cookies()).get(COOKIES.testCountry)?.value;
  return sampleClinic(isCountryCode(override) ? override : 'do');
});

export async function getClinicSnapshot(clinic: ClinicSettings): Promise<ClinicSnapshot> {
  if (!isSampleMode()) notConnected();
  return sampleSnapshot(clinic);
}

export type * from './types';
