import type { CountryProfile } from './countries';

/** Amounts are stored in USD and shown in the clinic's currency. */
export function formatMoney(usd: number, c: CountryProfile): string {
  const v = Math.round(usd * c.fx);
  return c.prefix + v.toLocaleString(c.locale, { maximumFractionDigits: 0, useGrouping: true }) + c.suffix;
}

/** "Maria Restrepo" → "Maria R." */
export const shortName = (name: string) => {
  const [first, last] = name.split(' ');
  return last ? `${first} ${last[0]}.` : first;
};
