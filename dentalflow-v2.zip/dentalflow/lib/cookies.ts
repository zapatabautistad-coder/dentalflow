/** Cookie names shared by server and client code. */
export const COOKIES = {
  lang: 'df_lang',
  /** Sample-mode session: holds the signed-in role. Supabase Auth replaces it. */
  session: 'df_session',
  /** Test panel (sample mode only). */
  testCountry: 'df_test_country',
} as const;
