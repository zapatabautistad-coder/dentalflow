import type { Metadata } from 'next';
import { DentalChart } from '@/components/odontogram/DentalChart';
import { LockedModule } from '@/components/shell/LockedModule';
import { getClinicSettings, getClinicSnapshot } from '@/lib/data';
import { translate } from '@/lib/i18n';
import { resolveLang } from '@/lib/lang';
import { canView } from '@/lib/roles';
import { getSession } from '@/lib/session';

export async function generateMetadata(): Promise<Metadata> {
  return { title: translate(await resolveLang(), 'nav_odontogram') };
}

export default async function OdontogramPage({ searchParams }: { searchParams: Promise<{ patient?: string }> }) {
  const [clinic, user, { patient }] = await Promise.all([getClinicSettings(), getSession(), searchParams]);
  if (!canView(user.role, 'odontogram')) return <LockedModule moduleKey="odontogram" />;

  const snapshot = await getClinicSnapshot(clinic);
  const initial = snapshot.patients.find((p) => p.id === patient)?.id ?? snapshot.patients[0]?.id ?? '';
  return <DentalChart patients={snapshot.patients} teeth={snapshot.teeth} plans={snapshot.plans} initialPatientId={initial} />;
}
