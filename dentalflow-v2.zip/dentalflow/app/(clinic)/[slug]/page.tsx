import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { LockedModule } from '@/components/shell/LockedModule';
import { PendingModule } from '@/components/shell/PendingModule';
import { translate } from '@/lib/i18n';
import { resolveLang } from '@/lib/lang';
import { canView, type ModuleKey } from '@/lib/roles';
import { getSession } from '@/lib/session';

/** Modules still to be built in this codebase (the dashboard and dental chart already are). */
const PENDING = ['queue', 'patients', 'appointments', 'schedules', 'treatments', 'billing', 'analytics'] as const satisfies readonly ModuleKey[];
type PendingKey = (typeof PENDING)[number];
const isPending = (v: string): v is PendingKey => (PENDING as readonly string[]).includes(v);

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  return isPending(slug) ? { title: translate(await resolveLang(), `nav_${slug}`) } : {};
}

export default async function ModulePage({ params }: Props) {
  const { slug } = await params;
  if (!isPending(slug)) notFound();
  const user = await getSession();
  if (!canView(user.role, slug)) return <LockedModule moduleKey={slug} />;
  return <PendingModule moduleKey={slug} />;
}
