import { AppProvider } from '@/components/providers/AppProvider';
import { AppShell } from '@/components/shell/AppShell';
import { getClinicSettings, isSampleMode } from '@/lib/data';
import { resolveLang } from '@/lib/lang';
import { getSession } from '@/lib/session';

export default async function ClinicLayout({ children }: { children: React.ReactNode }) {
  const [clinic, user, lang] = await Promise.all([getClinicSettings(), getSession(), resolveLang()]);
  return (
    <AppProvider clinic={clinic} user={user} initialLang={lang} testMode={isSampleMode()}>
      <AppShell>{children}</AppShell>
    </AppProvider>
  );
}
