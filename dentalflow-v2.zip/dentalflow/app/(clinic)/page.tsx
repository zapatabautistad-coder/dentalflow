import type { Metadata } from 'next';
import { Dashboard } from '@/components/dashboard/Dashboard';
import { getClinicSettings, getClinicSnapshot } from '@/lib/data';
import { translate } from '@/lib/i18n';
import { resolveLang } from '@/lib/lang';
import { can } from '@/lib/roles';
import { getSession } from '@/lib/session';

export async function generateMetadata(): Promise<Metadata> {
  return { title: translate(await resolveLang(), 'nav_dashboard') };
}

export default async function DashboardPage() {
  const [clinic, user] = await Promise.all([getClinicSettings(), getSession()]);
  const snapshot = await getClinicSnapshot(clinic);
  // Enforced on the server: roles without billing permission never receive invoice data.
  const visible = can(user.role, 'billing') ? snapshot : { ...snapshot, invoices: [] };
  return <Dashboard snapshot={visible} />;
}
