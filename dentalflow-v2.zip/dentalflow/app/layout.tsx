import type { Metadata, Viewport } from 'next';
import { Inter } from 'next/font/google';
import { resolveLang } from '@/lib/lang';
import './globals.css';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter', display: 'swap' });

export const metadata: Metadata = {
  title: { default: 'DentalFlow', template: '%s · DentalFlow' },
  description:
    'Practice management for dental clinics: patient queue, chairs, dental chart, treatment plans and country-aware billing.',
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#154360',
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const lang = await resolveLang();
  return (
    <html lang={lang} className={inter.variable}>
      <body className="font-sans antialiased">{children}</body>
    </html>
  );
}
