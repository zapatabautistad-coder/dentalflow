# DentalFlow

Practice management for dental clinics: waiting-room queue, chairs, dental chart, treatment plans and country-aware billing.

**Stack:** Next.js 16 (App Router) · React 19 · TypeScript · Tailwind CSS 4. No other runtime dependencies.

## Run it locally

Requires Node.js 20.9 or newer.

```bash
npm install
npm run dev
```

Open http://localhost:3000. For a production build: `npm run build && npm start`.

## What works in this version

| Area | Status |
|---|---|
| **Dashboard** | Today's appointments, waiting room (call / finish / check-in, turn numbers A-01…), chairs in use, key figures, rule-based AI suggestions (labelled as suggestions), quick actions, allergy flags on every patient row. |
| **Dental chart** | 32 teeth, 6 states, FDI or Universal numbering by country, findings with suggested action, linked treatment plan. Only dentists can edit. |
| **Roles** | Dentist (7/9 modules, no revenue data), Front desk (8/9, billing), Admin (9/9). Checked on the server: a role that may not see billing never receives invoice data. |
| **Countries** | International, US, Dominican Republic, Mexico, Colombia, Spain, UK — currency, tax name, fiscal-document numbering, tax-ID label, insurance label and tooth numbering. |
| **Languages** | Spanish / English (saved per browser; defaults to the browser language). |
| **Other modules** | Queue, Patients, Appointments, Schedules, Treatment plans, Billing, Analytics — placeholder pages, to be built next. |

## Data

`DATA_SOURCE=sample` (default) uses sample data built around **today's real date**, so the dashboard is always coherent. While sample data is on, the sidebar shows a **Test mode** panel to switch role and country.

When Supabase is connected, only `lib/data/index.ts` (data) and `lib/session.ts` (signed-in user and role) change; the UI components stay the same.

## Structure

```
app/
  (clinic)/layout.tsx        shell: loads clinic settings, session and language on the server
  (clinic)/page.tsx          dashboard
  (clinic)/odontogram/       dental chart
  (clinic)/[slug]/           modules still to build (+ server-side role check)
components/
  dashboard/  odontogram/  shell/  ui/  providers/
lib/
  data/        types, sample data, data entry point
  countries.ts roles.ts queue.ts i18n.ts time.ts format.ts clinic.ts session.ts
```

## Design

Brand palette: navy `#154360` + aqua `#8FD3C4` + white. Violet `#6D28D9` is reserved for AI suggestions. All tokens live in `app/globals.css`; every text colour meets WCAG AA contrast.

## Next steps

1. Supabase: Auth, `clinics`, `staff` (role per clinic), `patients`, `appointments`, `queue_entries`, `invoices`, `treatment_plans`, `dental_chart` with row-level security per clinic.
2. Server actions for check-in / call / finish / tooth changes, plus realtime updates for the waiting room.
3. Build the remaining modules from the v6 prototype.
