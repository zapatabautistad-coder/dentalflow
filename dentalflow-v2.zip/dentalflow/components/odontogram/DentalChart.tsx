'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { useApp } from '@/components/providers/AppProvider';
import { AllergyBadge } from '@/components/ui/StatusChip';
import type { DentalChart as Chart, Patient, ToothState, TreatmentPlan } from '@/lib/data/types';
import { can } from '@/lib/roles';

/* FDI order as seen from the front: upper 18→11 | 21→28, lower 48→41 | 31→38. */
const UPPER = [18, 17, 16, 15, 14, 13, 12, 11, 21, 22, 23, 24, 25, 26, 27, 28];
const LOWER = [48, 47, 46, 45, 44, 43, 42, 41, 31, 32, 33, 34, 35, 36, 37, 38];
const STATES: ToothState[] = ['healthy', 'caries', 'filled', 'endo', 'crown', 'missing'];

/** Fill for the drawing (≥3:1 on white) and a darker tone for text (≥4.5:1). */
const LOOK: Record<ToothState, { fill: string; text: string }> = {
  healthy: { fill: '#EEF2F7', text: '#64748B' },
  caries: { fill: '#DC2626', text: '#DC2626' },
  filled: { fill: '#3B82F6', text: '#1D4ED8' },
  endo: { fill: '#8B5CF6', text: '#6D28D9' },
  crown: { fill: '#D97706', text: '#B45309' },
  missing: { fill: '#64748B', text: '#64748B' },
};

const TOOTH_PATH =
  'M12 3.2c-1.5-1.2-3.2-1.7-4.7-1.3C5 2.6 4.4 5.2 5.2 7.8c.6 1.9.9 4 1.2 6 .3 1.5.8 3.2 1.9 3.2s1.4-1.3 1.7-2.8c.3-1.4.7-2.4 2-2.4s1.7 1 2 2.4c.3 1.5.6 2.8 1.7 2.8s1.6-1.7 1.9-3.2c.3-2 .6-4.1 1.2-6 .8-2.6.2-5.2-2.1-5.9-1.5-.4-3.2.1-4.7 1.3z';

function ToothGlyph({ state, upper }: { state: ToothState; upper: boolean }) {
  const c = LOOK[state].fill;
  const mark = '#0A1628';
  return (
    <svg viewBox="0 0 24 20" className={`h-[30px] w-[26px] ${upper ? 'rotate-180' : ''} ${state === 'missing' ? 'opacity-60' : ''}`} aria-hidden="true">
      {state === 'missing' ? (
        <>
          <path d={TOOTH_PATH} fill="none" stroke={c} strokeWidth={1.2} strokeDasharray="2 2" />
          <path d="M8 5l8 8M16 5l-8 8" stroke={c} strokeWidth={1.4} />
        </>
      ) : (
        <>
          <path d={TOOTH_PATH} fill={c} stroke={state === 'healthy' ? '#94A3B8' : 'none'} strokeWidth={1} />
          {state === 'endo' && <path d="M9.5 8v7M14.5 8v7" stroke={mark} strokeWidth={1.4} strokeLinecap="round" />}
          {state === 'filled' && <rect x={9} y={4.5} width={6} height={4} rx={1.4} fill={mark} opacity={0.55} />}
          {state === 'caries' && <circle cx={12} cy={7} r={2.2} fill={mark} opacity={0.6} />}
          {state === 'crown' && <path d="M6 6.5h12" stroke={mark} strokeWidth={1.3} opacity={0.6} />}
        </>
      )}
    </svg>
  );
}

export function DentalChart({
  patients, teeth, plans, initialPatientId,
}: {
  patients: Patient[];
  teeth: Chart;
  plans: TreatmentPlan[];
  initialPatientId: string;
}) {
  const { t, term, role, country, toast } = useApp();
  const router = useRouter();
  const [selected, setSelected] = useState(initialPatientId);
  const [chart, setChart] = useState<Chart>(teeth);
  const editable = can(role, 'clinical');
  const patient = patients.find((p) => p.id === selected) ?? patients[0];
  if (!patient) return null;
  const universal = country.numbering === 'Universal';

  /** Universal (US): upper 18→28 = 1→16, lower 38→48 = 17→32. */
  const label = (n: number) => {
    if (!universal) return n;
    const u = UPPER.indexOf(n);
    return u >= 0 ? u + 1 : 32 - LOWER.indexOf(n);
  };
  const stateOf = (n: number): ToothState => chart[patient.id]?.[n] ?? 'healthy';

  const counts = Object.fromEntries(STATES.map((s) => [s, 0])) as Record<ToothState, number>;
  [...UPPER, ...LOWER].forEach((n) => counts[stateOf(n)]++);
  const findings = [...UPPER, ...LOWER].filter((n) => stateOf(n) !== 'healthy').sort((a, b) => label(a) - label(b));
  const linkedPlans = plans.filter((p) => p.patientId === patient.id);

  function selectPatient(id: string) {
    setSelected(id);
    router.replace(`/odontogram?patient=${id}`, { scroll: false });
  }

  function cycle(n: number) {
    if (!editable) return toast(t('o_roT', { n: label(n) }));
    const next = STATES[(STATES.indexOf(stateOf(n)) + 1) % STATES.length];
    setChart((c) => ({ ...c, [patient.id]: { ...c[patient.id], [n]: next } }));
    toast(t('o_upd', { n: label(n), s: t(`st_${next}`) }));
  }

  function resetAll() {
    setChart((c) => ({ ...c, [patient.id]: {} }));
    toast(t('o_resetT'));
  }

  const tooth = (n: number, upper: boolean) => {
    const s = stateOf(n);
    const name = `${t('o_tooth', { n: label(n) })}: ${t(`st_${s}`)}`;
    return (
      <button
        key={n}
        type="button"
        onClick={() => cycle(n)}
        aria-label={name}
        title={name}
        aria-disabled={!editable || undefined}
        className={[
          'flex items-center gap-1 rounded-[10px] border border-line bg-white px-0.5 py-1.5 transition',
          upper ? 'flex-col-reverse' : 'flex-col',
          editable ? 'hover:border-brand hover:shadow-[0_4px_12px_rgb(21_67_96/0.16)]' : 'cursor-default',
        ].join(' ')}
      >
        <span className="tabular text-xs font-semibold text-ink-2">{label(n)}</span>
        <ToothGlyph state={s} upper={upper} />
        <span className="min-h-4 text-xs font-semibold tracking-wide" style={{ color: LOOK[s].text }}>{t(`sx_${s}`)}</span>
      </button>
    );
  };
  const arch = (row: number[], upper: boolean) => (
    <div className="grid grid-cols-[repeat(8,minmax(0,1fr))_14px_repeat(8,minmax(0,1fr))] items-end gap-1.5">
      {row.slice(0, 8).map((n) => tooth(n, upper))}
      <div className="mx-auto w-0 self-stretch border-l border-dashed border-line" aria-hidden="true" />
      {row.slice(8).map((n) => tooth(n, upper))}
    </div>
  );
  const sides = (arcLabel: string) => (
    <div className="my-2 flex justify-between px-0.5 text-xs font-medium uppercase tracking-wider text-ink-3">
      <span>{t('o_right')}</span><span>{arcLabel}</span><span>{t('o_left')}</span>
    </div>
  );

  return (
    <div className="mx-auto max-w-[1400px] space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-ink">{t('o_title', { name: patient.name })}</h1>
          <p className="text-sm text-ink-2">{t(editable ? 'o_sub' : 'o_subRO', { nt: country.numbering })}</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <label className="sr-only" htmlFor="odo-patient">{t('patient')}</label>
          <select
            id="odo-patient"
            value={patient.id}
            onChange={(e) => selectPatient(e.target.value)}
            className="rounded-[10px] border border-brand/35 bg-white px-3 py-2 text-sm text-ink"
          >
            {patients.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
          {editable && <button type="button" onClick={resetAll} className="btn-ghost px-3.5 py-2 text-sm">{t('o_reset')}</button>}
        </div>
      </div>

      {patient.allergy && <AllergyBadge allergy={patient.allergy} />}

      {!editable && (
        <p role="note" className="rounded-xl border-l-[3px] border-ink-3 bg-white/80 px-4 py-2.5 text-[13px] text-ink-2">{t('o_ro')}</p>
      )}

      <div className="grid grid-cols-1 items-start gap-5 xl:grid-cols-[minmax(0,1fr)_300px]">
        <section className="card p-5" aria-label={t('o_title', { name: patient.name })}>
          <ul className="flex flex-wrap gap-2" aria-label={t('o_legend')}>
            {STATES.map((s) => (
              <li key={s} className="inline-flex items-center gap-1.5 rounded-full border border-line bg-surface px-2.5 py-0.5 text-xs font-medium" style={{ color: LOOK[s].text }}>
                <i aria-hidden="true" className={`size-2 rounded-full ${s === 'healthy' ? 'ring-1 ring-ink-3' : ''}`} style={{ background: LOOK[s].fill }} />
                {t(`st_${s}`)} · <span className="tabular">{counts[s]}</span>
              </li>
            ))}
          </ul>

          <div className="mt-4 overflow-x-auto pb-1" tabIndex={0} role="region" aria-label={t('o_title', { name: patient.name })}>
            <div className="min-w-[760px]">
              {sides(t('o_upper'))}
              {arch(UPPER, true)}
              <div className="my-3.5 h-px bg-line" aria-hidden="true" />
              {arch(LOWER, false)}
              {sides(t('o_lower'))}
            </div>
          </div>
        </section>

        <div className="space-y-5">
          <section className="card p-5" aria-labelledby="find-title">
            <h2 id="find-title" className="text-xs font-semibold uppercase tracking-wider text-ink-3">
              {t('o_find')} · <span className="tabular">{findings.length}</span>
            </h2>
            {findings.length ? (
              <ul className="mt-2 divide-y divide-line">
                {findings.map((n) => {
                  const s = stateOf(n);
                  const sug = s === 'healthy' ? null : t(`sug_${s}`);
                  return (
                    <li key={n} className="flex items-center justify-between gap-3 py-2.5 text-[13px]">
                      <span className="shrink-0 whitespace-nowrap">
                        <b className="tabular text-ink">{label(n)}</b> · <span className="font-medium" style={{ color: LOOK[s].text }}>{t(`st_${s}`)}</span>
                      </span>
                      {sug && <span className="text-right text-xs text-ink-2">{sug}</span>}
                    </li>
                  );
                })}
              </ul>
            ) : (
              <p className="mt-2 text-[13px] text-ink-2">{t('o_none')}</p>
            )}
          </section>

          {linkedPlans.map((plan) => (
            <section key={plan.id} className="card p-5">
              <h2 className="text-xs font-semibold uppercase tracking-wider text-ink-3">{t('nav_treatments')}</h2>
              <p className="mt-2 text-[13px] text-ink">{t('o_plan', { p: term(plan.name), n: label(plan.tooth) })}</p>
              <Link href="/treatments" className="mt-3 inline-block text-[13px] font-semibold text-brand-ink hover:underline">
                {t('nav_treatments')} →
              </Link>
            </section>
          ))}
        </div>
      </div>
    </div>
  );
}
