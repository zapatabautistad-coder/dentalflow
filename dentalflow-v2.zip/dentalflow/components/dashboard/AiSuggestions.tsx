'use client';

import Link from 'next/link';
import { useApp } from '@/components/providers/AppProvider';
import { Icon } from '@/components/ui/Icon';

export interface Suggestion {
  id: string;
  text: string;
  action?: { label: string; href?: string; onClick?: () => void };
}

/** Rule-based suggestions, labelled as such. Teal is reserved for this card. */
export function AiSuggestions({ items }: { items: Suggestion[] }) {
  const { t } = useApp();
  if (!items.length) return null;
  const actionCls = 'whitespace-nowrap text-[13px] font-semibold text-ai hover:underline';

  return (
    <section className="ai-card px-5 py-4" aria-labelledby="ai-title">
      <h2 id="ai-title" className="flex flex-wrap items-center gap-x-2 text-xs font-semibold uppercase tracking-wider text-ai">
        <Icon name="spark" className="size-4" />
        {t('aiTitle')}
        <span className="font-normal normal-case tracking-normal text-ink-2">· {t('aiNote')}</span>
      </h2>
      <ul className="mt-1.5 divide-y divide-line">
        {items.map((s) => (
          <li key={s.id} className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1 py-2 text-[13.5px] text-ink">
            <span>{s.text}</span>
            {s.action?.href && <Link href={s.action.href} className={actionCls}>{s.action.label} →</Link>}
            {s.action?.onClick && (
              <button type="button" onClick={s.action.onClick} className={actionCls}>{s.action.label} →</button>
            )}
          </li>
        ))}
      </ul>
    </section>
  );
}
