'use client';

import { useMemo, useState } from 'react';
import { useApp } from '@/components/providers/AppProvider';
import type { Appointment, ClinicSnapshot, Patient, QueueEntry } from '@/lib/data/types';
import { formatMoney, shortName } from '@/lib/format';
import {
  averageWait, freeChair, inChair, pickDentist, stuckSuggestion, turnLabel, waitingList, waitMinutes,
} from '@/lib/queue';
import { can } from '@/lib/roles';
import { sameDay } from '@/lib/time';
import { useNow } from '@/lib/use-now';
import { AiSuggestions, type Suggestion } from './AiSuggestions';
import { CheckInDialog } from './CheckInDialog';
import { KpiCard, KpiLocked } from './KpiCard';
import { QuickActions } from './QuickActions';
import { TodayAgenda, type AgendaFilter, type AgendaRow } from './TodayAgenda';
import { WaitingRoom } from './WaitingRoom';

const UNKNOWN: Patient = { id: '?', initials: '??', name: '—', age: 0, phone: '', insurance: '', allergy: null, lastVisit: null, lifetimeValueUsd: 0, outstandingUsd: 0 };

export function Dashboard({ snapshot }: { snapshot: ClinicSnapshot }) {
  const { t, term, clinic, country, role, user, roleName, toast } = useApp();
  const tz = clinic.timeZone;
  const now = useNow(snapshot.now);

  /* Local working state. With Supabase these become server actions + realtime updates. */
  const [queue, setQueue] = useState<QueueEntry[]>(snapshot.queue);
  const [appointments, setAppointments] = useState<Appointment[]>(snapshot.appointments);
  const [filter, setFilter] = useState<AgendaFilter>('all');
  const [checkInOpen, setCheckInOpen] = useState(false);

  const patients = useMemo(() => new Map(snapshot.patients.map((p) => [p.id, p])), [snapshot.patients]);
  const patientOf = (id: string) => patients.get(id) ?? UNKNOWN;
  const appointmentOf = (id: string | null) => (id ? appointments.find((a) => a.id === id) : undefined);

  const today = appointments
    .filter((a) => sameDay(a.startsAt, now, tz))
    .sort((a, b) => a.startsAt.localeCompare(b.startsAt));
  const entryByAppt = new Map(queue.filter((e) => e.appointmentId).map((e) => [e.appointmentId as string, e]));
  const waiting = waitingList(queue);
  const busyChairs = inChair(queue).length;
  const pendingConfirm = today.filter((a) => a.status === 'Pending' && !entryByAppt.has(a.id)).length;

  const open = snapshot.invoices.filter((i) => i.status !== 'Paid');
  const overdueList = snapshot.invoices.filter((i) => i.status === 'Overdue');
  const outstanding = open.reduce((s, i) => s + i.amountUsd, 0);
  const overdue = overdueList.reduce((s, i) => s + i.amountUsd, 0);

  /* ---------- actions ---------- */
  const nowIso = () => now.toISOString();

  function callPatient(id: string) {
    const e = queue.find((x) => x.id === id);
    if (!e) return;
    const chair = freeChair(queue, clinic);
    if (!chair) return toast(t('noChair'));
    const dentist = pickDentist(e, queue, clinic, now);
    if (!dentist) return toast(t('drBusy', { dr: e.dentist === 'any' ? t('anyDr') : e.dentist }));
    setQueue((q) => q.map((x) => (x.id === id ? { ...x, status: 'In chair', chair, dentist, calledAt: nowIso() } : x)));
    if (e.appointmentId) setAppointments((as) => as.map((a) => (a.id === e.appointmentId ? { ...a, status: 'In progress' } : a)));
    toast(t('calledT', { no: turnLabel(e.no), name: shortName(patientOf(e.patientId).name), ch: term(chair) }));
  }

  function finishPatient(id: string) {
    const e = queue.find((x) => x.id === id);
    if (!e) return;
    setQueue((q) => q.map((x) => (x.id === id ? { ...x, status: 'Done', finishedAt: nowIso() } : x)));
    if (e.appointmentId) setAppointments((as) => as.map((a) => (a.id === e.appointmentId ? { ...a, status: 'Completed' } : a)));
    toast(t('finishedT', { no: turnLabel(e.no), ch: term(e.chair ?? '') }));
  }

  function checkIn(patientId: string) {
    const appt = today.find((a) => a.patientId === patientId && !entryByAppt.has(a.id) && (a.status === 'Confirmed' || a.status === 'Pending'));
    const no = Math.max(0, ...queue.map((e) => e.no)) + 1;
    const entry: QueueEntry = {
      id: `q-${no}-${Date.now()}`, no, patientId, appointmentId: appt?.id ?? null,
      arrivedAt: nowIso(), dentist: appt?.dentist ?? 'any', status: 'Waiting',
    };
    setQueue((q) => [...q, entry]);
    toast(t('checkedT', { name: patientOf(patientId).name, no: turnLabel(no) }));
  }

  function reassign(id: string, dentist: string) {
    const e = queue.find((x) => x.id === id);
    if (!e) return;
    setQueue((q) => q.map((x) => (x.id === id ? { ...x, dentist } : x)));
    if (e.appointmentId) setAppointments((as) => as.map((a) => (a.id === e.appointmentId ? { ...a, dentist } : a)));
    toast(t('reassignT', { no: turnLabel(e.no), dr: dentist }));
  }

  /* ---------- derived views ---------- */
  const showFilter = role === 'doctor' && !!user.name;
  const rows: AgendaRow[] = today
    .filter((a) => !showFilter || filter === 'all' || a.dentist === user.name)
    .map((appt) => ({ appt, patient: patientOf(appt.patientId), entry: entryByAppt.get(appt.id) }));

  const suggestions: Suggestion[] = [];
  const stuck = stuckSuggestion(queue, clinic, now);
  suggestions.push(
    stuck
      ? {
          id: 'stuck',
          text: t('ai_stuck', { no: turnLabel(stuck.entry.no), m: waitMinutes(stuck.entry, now), dr: stuck.entry.dentist, dr2: stuck.alt }),
          action: { label: t('ai_stuckA', { dr2: stuck.alt }), onClick: () => reassign(stuck.entry.id, stuck.alt) },
        }
      : { id: 'flow', text: t('ai_flow') },
  );
  for (const plan of snapshot.plans) {
    for (const stage of plan.stages.filter((s) => s.state === 'alert')) {
      suggestions.push({
        id: `plan-${plan.id}-${stage.n}`,
        text: t('ai_plan', { name: patientOf(plan.patientId).name, s: stage.n }),
        action: { label: t('ai_planA'), href: '/treatments' },
      });
    }
  }
  if (can(role, 'billing') && overdue > 0) {
    suggestions.push({
      id: 'overdue',
      text: t('ai_over', { v: formatMoney(overdue, country), n: overdueList.length }),
      action: { label: t('ai_overA'), href: '/billing' },
    });
  }

  const inQueue = new Set(queue.map((e) => e.patientId));
  const candidates = snapshot.patients.filter((p) => !inQueue.has(p.id));
  const todaysApptFor = (patientId: string) =>
    today.find((a) => a.patientId === patientId && !entryByAppt.has(a.id) && (a.status === 'Confirmed' || a.status === 'Pending'));

  return (
    <div className="mx-auto max-w-[1400px] space-y-5">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-ink">{t('nav_dashboard')}</h1>
        <p className="text-sm text-ink-2">{clinic.name}</p>
      </div>

      {snapshot.sample && (
        <p role="note" className="rounded-xl border border-brand/30 bg-white/70 px-4 py-2.5 text-[13px] text-ink-2">
          {t('sampleNote')}
        </p>
      )}

      <section aria-label={t('kpis')} className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard
          tone="navy"
          label={t('k_today')}
          value={String(today.length)}
          detail={pendingConfirm ? t('k_todayPend', { n: pendingConfirm }) : t('k_todayOk')}
        />
        <KpiCard
          tone="aqua"
          label={t('k_wait')}
          value={String(waiting.length)}
          detail={waiting.length ? t('k_waitD', { m: averageWait(waiting, now) }) : t('k_waitNone')}
        />
        <KpiCard
          tone="ocean"
          label={t('k_chairs')}
          value={t('k_chairsV', { a: busyChairs, b: clinic.chairs.length })}
          detail={t('k_chairsD', { n: clinic.chairs.length - busyChairs })}
        />
        {can(role, 'billing') ? (
          <KpiCard
            tone="steel"
            label={t('k_pend')}
            value={formatMoney(outstanding, country)}
            detail={overdue ? t('k_pendD', { v: formatMoney(overdue, country) }) : t('k_pendNone')}
          />
        ) : (
          <KpiLocked label={t('k_pend')} reason={t('k_locked', { r: roleName() })} />
        )}
      </section>

      <AiSuggestions items={suggestions} />

      <div className="grid grid-cols-1 items-start gap-5 xl:grid-cols-12">
        <TodayAgenda
          className="xl:col-span-7 2xl:col-span-8"
          rows={rows}
          filter={filter}
          onFilter={setFilter}
          showFilter={showFilter}
          onCheckIn={checkIn}
        />
        <div className="space-y-5 xl:col-span-5 2xl:col-span-4">
          <WaitingRoom
            queue={queue}
            now={now}
            patientOf={patientOf}
            appointmentOf={appointmentOf}
            onCall={callPatient}
            onFinish={finishPatient}
          />
          <QuickActions onCheckIn={() => setCheckInOpen(true)} />
        </div>
      </div>

      <CheckInDialog
        open={checkInOpen}
        onClose={() => setCheckInOpen(false)}
        candidates={candidates}
        appointmentFor={todaysApptFor}
        onConfirm={checkIn}
      />
    </div>
  );
}
