'use client';

import Link from 'next/link';
import { useApp } from '@/components/providers/AppProvider';
import { Icon, type IconName } from '@/components/ui/Icon';
import { can } from '@/lib/roles';

const TILE =
  'flex flex-col items-center justify-center gap-1.5 rounded-xl border border-line bg-white px-3 py-3.5 text-center text-[13px] font-semibold text-ink transition-colors hover:border-brand/50 hover:bg-brand/5';

function Tile({ icon, label, href, onClick }: { icon: IconName; label: string; href?: string; onClick?: () => void }) {
  const body = (<><Icon name={icon} className="size-5 text-brand" />{label}</>);
  return href ? <Link href={href} className={TILE}>{body}</Link> : <button type="button" onClick={onClick} className={TILE}>{body}</button>;
}

export function QuickActions({ onCheckIn }: { onCheckIn: () => void }) {
  const { t, role } = useApp();
  return (
    <section className="card p-5" aria-labelledby="qa-title">
      <h2 id="qa-title" className="text-[15px] font-semibold text-ink">{t('qaTitle')}</h2>
      <div className="mt-3 grid grid-cols-2 gap-2.5">
        <Tile icon="checkIn" label={t('qa_checkin')} onClick={onCheckIn} />
        <Tile icon="userPlus" label={t('qa_newPt')} href="/patients?new=1" />
        <Tile icon="odontogram" label={t('qa_chart')} href="/odontogram" />
        {can(role, 'billing') && <Tile icon="billing" label={t('qa_pay')} href="/billing" />}
      </div>
    </section>
  );
}
