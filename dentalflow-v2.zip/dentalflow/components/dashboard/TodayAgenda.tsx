'use client';

import Link from 'next/link';
import { useApp } from '@/components/providers/AppProvider';
import { AllergyBadge, StatusChip } from '@/components/ui/StatusChip';
import type { Appointment, Patient, QueueEntry } from '@/lib/data/types';
import { turnLabel } from '@/lib/queue';
import { fmtClock } from '@/lib/time';

export interface AgendaRow {
  appt: Appointment;
  patient: Patient;
  entry: QueueEntry | undefined;
}

export type AgendaFilter = 'all' | 'mine';

/** Queue state wins over the booking status once the patient has arrived. */
const liveStatus = (r: AgendaRow) =>
  r.entry ? (r.entry.status === 'Done' ? 'Completed' : r.entry.status) : r.appt.status;

export function TodayAgenda({
  rows, filter, onFilter, showFilter, onCheckIn, className = '',
}: {
  rows: AgendaRow[];
  filter: AgendaFilter;
  onFilter: (f: AgendaFilter) => void;
  showFilter: boolean;
  onCheckIn: (patientId: string) => void;
  className?: string;
}) {
  const { t, term, clinic } = useApp();
  const tz = clinic.timeZone;

  return (
    <section className={`card flex flex-col ${className}`} aria-labelledby="agenda-title">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line px-5 py-4">
        <div>
          <h2 id="agenda-title" className="text-[15px] font-semibold text-ink">{t('agendaTitle')}</h2>
          <p className="text-xs text-ink-2">{t('agendaSub', { n: rows.length })}</p>
        </div>
        <div className="flex items-center gap-3">
          {showFilter && (
            <div className="seg" role="group" aria-label={t('showAppts')}>
              {(['mine', 'all'] as const).map((f) => (
                <button key={f} type="button" aria-pressed={filter === f} onClick={() => onFilter(f)}>{t(f)}</button>
              ))}
            </div>
          )}
          <Link href="/appointments" className="text-[13px] font-semibold text-brand-ink hover:underline">{t('viewCal')} →</Link>
        </div>
      </div>

      {rows.length === 0 ? (
        <p className="px-5 py-8 text-center text-sm text-ink-2">{filter === 'mine' ? t('noMine') : t('noAppts')}</p>
      ) : (
        <ul className="divide-y divide-line">
          {rows.map((r) => {
            const status = liveStatus(r);
            const canCheckIn = !r.entry && (r.appt.status === 'Confirmed' || r.appt.status === 'Pending');
            return (
              <li key={r.appt.id} className="grid grid-cols-[64px_1fr] items-center gap-x-4 gap-y-2.5 px-5 py-3.5 transition-colors hover:bg-surface sm:grid-cols-[64px_1fr_auto]">
                <div className="tabular">
                  <p className="text-sm font-bold text-ink">{fmtClock(r.appt.startsAt, tz)}</p>
                  <p className="text-xs text-ink-3">{t('minutes', { n: r.appt.durationMin })}</p>
                </div>
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                    <span className="font-semibold text-ink">{r.patient.name}</span>
                    {r.entry && (
                      <span className="tabular rounded-md border border-line bg-surface px-1.5 py-0.5 text-xs font-semibold text-ink-2">
                        {t('turnOf', { no: turnLabel(r.entry.no) })}
                      </span>
                    )}
                    <AllergyBadge allergy={r.patient.allergy} />
                  </div>
                  <p className="mt-0.5 text-[13px] text-ink-2">
                    {term(r.appt.treatment)} · {r.appt.dentist} · {term(r.appt.chair)}
                  </p>
                </div>
                <div className="col-span-2 flex flex-wrap items-center gap-2 sm:col-span-1 sm:justify-end">
                  <StatusChip status={status} />
                  {canCheckIn && (
                    <button type="button" className="btn-glass px-3 py-1.5 text-xs" onClick={() => onCheckIn(r.patient.id)}>
                      {t('checkIn')}
                    </button>
                  )}
                  <Link
                    href={`/patients?id=${r.patient.id}`}
                    className="btn-ghost px-3 py-1.5 text-xs"
                    aria-label={`${t('patientFile')}: ${r.patient.name}`}
                  >
                    {t('patientFile')}
                  </Link>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
