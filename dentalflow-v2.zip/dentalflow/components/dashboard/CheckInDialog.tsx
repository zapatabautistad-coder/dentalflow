'use client';

import { useEffect, useRef, useState } from 'react';
import { useApp } from '@/components/providers/AppProvider';
import type { Appointment, Patient } from '@/lib/data/types';
import { fmtClock } from '@/lib/time';

export function CheckInDialog({
  open, onClose, candidates, appointmentFor, onConfirm,
}: {
  open: boolean;
  onClose: () => void;
  candidates: Patient[];
  appointmentFor: (patientId: string) => Appointment | undefined;
  onConfirm: (patientId: string) => void;
}) {
  const { t, clinic } = useApp();
  const ref = useRef<HTMLDialogElement>(null);
  const [selected, setSelected] = useState('');

  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (open && !d.open) {
      setSelected(candidates[0]?.id ?? '');
      d.showModal();
    } else if (!open && d.open) {
      d.close();
    }
  }, [open, candidates]);

  const appt = selected ? appointmentFor(selected) : undefined;

  return (
    <dialog
      ref={ref}
      onClose={onClose}
      aria-labelledby="ci-title"
      className="m-auto w-[min(440px,92vw)] rounded-2xl border border-line bg-white p-0 text-ink shadow-2xl backdrop:bg-slate-900/35 backdrop:backdrop-blur-sm"
    >
      <form
        className="space-y-4 p-6"
        onSubmit={(e) => {
          e.preventDefault();
          if (!selected) return;
          onConfirm(selected);
          onClose();
        }}
      >
        <div>
          <h2 id="ci-title" className="text-lg font-semibold tracking-tight">{t('ci_title')}</h2>
          <p className="text-[13px] text-ink-2">{t('ci_sub')}</p>
        </div>

        {candidates.length ? (
          <>
            <label className="block">
              <span className="mb-1.5 block text-xs font-medium uppercase tracking-wider text-ink-2">{t('patient')}</span>
              <select
                value={selected}
                onChange={(e) => setSelected(e.target.value)}
                className="w-full rounded-lg border border-line bg-white px-3 py-2.5 text-sm text-ink"
              >
                {candidates.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </label>
            <p className="rounded-lg bg-surface px-3 py-2.5 text-[13px] text-ink-2" aria-live="polite">
              {appt ? t('ci_hasAppt', { h: fmtClock(appt.startsAt, clinic.timeZone), dr: appt.dentist }) : t('ci_noAppt')}
            </p>
          </>
        ) : (
          <p className="text-[13px] text-ink-2">{t('allInQueue')}</p>
        )}

        <div className="flex justify-end gap-2 pt-1">
          <button type="button" className="btn-ghost px-4 py-2 text-sm" onClick={onClose}>{t('cancel')}</button>
          <button type="submit" className="btn-glass px-4 py-2 text-sm" disabled={!selected}>{t('ci_btn')}</button>
        </div>
      </form>
    </dialog>
  );
}
