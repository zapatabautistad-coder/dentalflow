'use client';

import Link from 'next/link';
import { useApp } from '@/components/providers/AppProvider';
import { Icon } from '@/components/ui/Icon';
import { AllergyBadge, Chip } from '@/components/ui/StatusChip';
import type { Appointment, Patient, QueueEntry } from '@/lib/data/types';
import { shortName } from '@/lib/format';
import { inChair, turnLabel, waitingList, waitLevel, waitMinutes } from '@/lib/queue';
import { fmtClock } from '@/lib/time';

const WAIT_TEXT = { ok: 'text-ink-2', warn: 'text-warn', bad: 'text-bad' } as const;

export function WaitingRoom({
  queue, now, patientOf, appointmentOf, onCall, onFinish,
}: {
  queue: QueueEntry[];
  now: Date;
  patientOf: (id: string) => Patient;
  appointmentOf: (id: string | null) => Appointment | undefined;
  onCall: (entryId: string) => void;
  onFinish: (entryId: string) => void;
}) {
  const { t, term, clinic, role, user } = useApp();
  const tz = clinic.timeZone;
  const occupied = inChair(queue);
  const waiting = waitingList(queue);

  return (
    <section className="card p-5" aria-labelledby="wr-title">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h2 id="wr-title" className="text-[15px] font-semibold text-ink">{t('wrTitle')}</h2>
          <p className="tabular text-xs text-ink-2">{t('wrSub', { c: fmtClock(now, tz) })}</p>
        </div>
        <Link href="/queue" className="whitespace-nowrap text-[13px] font-semibold text-brand-ink hover:underline">{t('openQueue')} →</Link>
      </div>

      <h3 className="mt-4 text-xs font-semibold uppercase tracking-wider text-ink-3">{t('chairs')}</h3>
      <ul className="mt-2 space-y-2">
        {clinic.chairs.map((chair) => {
          const e = occupied.find((x) => x.chair === chair);
          const p = e && patientOf(e.patientId);
          return (
            <li key={chair} className="flex min-h-[52px] items-center gap-3 rounded-xl border border-line bg-surface px-3 py-2">
              <span className="w-[4.5rem] shrink-0 text-[13px] font-semibold text-ink">{term(chair)}</span>
              {e && p ? (
                <>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13px] font-medium text-ink">
                      <span className="tabular font-bold text-brand-ink">{turnLabel(e.no)}</span> · {shortName(p.name)}
                    </p>
                    <p className="truncate text-xs text-ink-2">
                      {e.dentist} · {t('since', { t: e.calledAt ? fmtClock(e.calledAt, tz) : '—' })}
                    </p>
                  </div>
                  {role === 'doctor' && (
                    <Link
                      href={`/odontogram?patient=${p.id}`}
                      className="btn-ghost size-8 shrink-0 p-0"
                      aria-label={t('openChart', { name: p.name })}
                      title={t('openChart', { name: p.name })}
                    >
                      <Icon name="odontogram" className="size-4" />
                    </Link>
                  )}
                  <button type="button" className="btn-ghost shrink-0 px-2.5 py-1.5 text-xs" onClick={() => onFinish(e.id)}>
                    {t('finish')}
                  </button>
                </>
              ) : (
                <Chip tone="ok">{t('free')}</Chip>
              )}
            </li>
          );
        })}
      </ul>

      <h3 className="mt-5 text-xs font-semibold uppercase tracking-wider text-ink-3">
        {t('waitingList')} · <span className="tabular">{waiting.length}</span>
      </h3>
      {waiting.length === 0 ? (
        <p className="mt-2 text-[13px] text-ink-2">{t('queueEmpty')}</p>
      ) : (
        <ul className="mt-1 divide-y divide-line">
          {waiting.map((e) => {
            const p = patientOf(e.patientId);
            const appt = appointmentOf(e.appointmentId);
            const wm = waitMinutes(e, now);
            const mine = role === 'doctor' && !!user.name && e.dentist === user.name;
            return (
              <li key={e.id} className="flex items-center gap-3 py-2.5">
                <span className="tabular grid h-8 min-w-12 shrink-0 place-items-center rounded-lg border border-line bg-white px-1.5 text-xs font-bold text-ink">
                  {turnLabel(e.no)}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[13px] font-medium text-ink">
                    {shortName(p.name)}
                    {mine && <span className="rounded-md bg-brand/10 px-1.5 py-0.5 text-xs font-semibold text-brand-ink">{t('forYou')}</span>}
                    <AllergyBadge allergy={p.allergy} />
                  </p>
                  <p className="text-xs text-ink-2">
                    {appt ? t('apptAt', { h: fmtClock(appt.startsAt, tz) }) : t('walkin')} · {e.dentist === 'any' ? t('anyDr') : e.dentist} · {t('arrived', { t: fmtClock(e.arrivedAt, tz) })}
                  </p>
                </div>
                <span className={`tabular shrink-0 text-xs font-semibold ${WAIT_TEXT[waitLevel(wm)]}`}>{t('minutes', { n: wm })}</span>
                <button
                  type="button"
                  className="btn-glass shrink-0 px-3 py-1.5 text-xs"
                  onClick={() => onCall(e.id)}
                  aria-label={`${t('call')} ${turnLabel(e.no)} · ${p.name}`}
                >
                  {t('call')}
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
