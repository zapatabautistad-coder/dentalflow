import { Icon } from '@/components/ui/Icon';

export type KpiTone = 'navy' | 'aqua' | 'ocean' | 'steel';

export function KpiCard({ label, value, detail, tone }: { label: string; value: string; detail: string; tone: KpiTone }) {
  return (
    <div className={`kpi kpi-${tone} px-5 py-4`}>
      <p className="text-xs font-medium uppercase tracking-wider">{label}</p>
      <p className="tabular my-1.5 text-[34px] font-bold leading-none tracking-tight">{value}</p>
      <p className="flex items-center gap-1.5 text-[13px] font-medium">
        <i aria-hidden="true" className="size-1.5 rounded-full bg-white" />
        {detail}
      </p>
    </div>
  );
}

/** Shown instead of a KPI the current role may not see. */
export function KpiLocked({ label, reason }: { label: string; reason: string }) {
  return (
    <div className="kpi kpi-locked px-5 py-4">
      <p className="text-xs font-medium uppercase tracking-wider">{label}</p>
      <p className="my-1.5 flex h-[34px] items-center" aria-hidden="true">
        <Icon name="lock" className="size-7" />
      </p>
      <p className="text-[13px] font-medium">{reason}</p>
    </div>
  );
}
