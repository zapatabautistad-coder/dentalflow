'use client';

import { useRouter } from 'next/navigation';
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, useTransition } from 'react';
import type { ClinicSettings } from '@/lib/clinic';
import { COOKIES } from '@/lib/cookies';
import { COUNTRIES, l2, type CountryCode, type CountryProfile } from '@/lib/countries';
import { term as termFn, translate, type Lang, type MsgKey, type Vars } from '@/lib/i18n';
import { MODULES, ROLES, type Role } from '@/lib/roles';
import type { SessionUser } from '@/lib/session';

interface AppContextValue {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (key: MsgKey, vars?: Vars) => string;
  term: (s: string) => string;
  clinic: ClinicSettings;
  country: CountryProfile;
  user: SessionUser;
  role: Role;
  roleName: (r?: Role) => string;
  /** Sample data is active: shows the test panel (role / country switch). */
  testMode: boolean;
  pending: boolean;
  setTestRole: (r: Role) => void;
  setTestCountry: (c: CountryCode) => void;
  toast: (msg: string) => void;
}

const AppContext = createContext<AppContextValue | null>(null);

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside <AppProvider>');
  return ctx;
}

const setCookie = (name: string, value: string) => {
  document.cookie = `${name}=${encodeURIComponent(value)}; path=/; max-age=31536000; samesite=lax`;
};

export function AppProvider({
  clinic, user, initialLang, testMode, children,
}: {
  clinic: ClinicSettings;
  user: SessionUser;
  initialLang: Lang;
  testMode: boolean;
  children: React.ReactNode;
}) {
  const router = useRouter();
  const [lang, setLangState] = useState<Lang>(initialLang);
  const [pending, startTransition] = useTransition();
  const [toastMsg, setToastMsg] = useState<{ id: number; msg: string } | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  const t = useCallback((key: MsgKey, vars?: Vars) => translate(lang, key, vars), [lang]);
  const term = useCallback((s: string) => termFn(lang, s), [lang]);
  const roleName = useCallback((r?: Role) => translate(lang, `r_${r ?? user.role}`), [lang, user.role]);

  const toast = useCallback((msg: string) => {
    clearTimeout(timer.current);
    setToastMsg({ id: Date.now(), msg });
    timer.current = setTimeout(() => setToastMsg(null), 3200);
  }, []);
  useEffect(() => () => clearTimeout(timer.current), []);

  const setLang = useCallback((l: Lang) => {
    setLangState(l);
    setCookie(COOKIES.lang, l);
    document.documentElement.lang = l;
  }, []);

  const setTestRole = useCallback((r: Role) => {
    setCookie(COOKIES.session, r);
    startTransition(() => router.refresh());
    toast(translate(lang, 'roleT', { r: translate(lang, `r_${r}`), a: ROLES[r].modules.length, b: MODULES.length }));
  }, [lang, router, toast]);

  const setTestCountry = useCallback((c: CountryCode) => {
    setCookie(COOKIES.testCountry, c);
    startTransition(() => router.refresh());
    const p = COUNTRIES[c];
    toast(translate(lang, 'countryT', { c: l2(lang, p.name), cur: p.currency, tax: l2(lang, p.taxName) }));
  }, [lang, router, toast]);

  const value = useMemo<AppContextValue>(() => ({
    lang, setLang, t, term, clinic, country: COUNTRIES[clinic.country], user, role: user.role, roleName,
    testMode, pending, setTestRole, setTestCountry, toast,
  }), [lang, setLang, t, term, clinic, user, roleName, testMode, pending, setTestRole, setTestCountry, toast]);

  return (
    <AppContext.Provider value={value}>
      {children}
      <div aria-live="polite" role="status" className="pointer-events-none fixed inset-x-0 bottom-6 z-[60] flex justify-center px-4">
        {toastMsg && (
          <div
            key={toastMsg.id}
            className="rounded-xl border border-aqua-ink/40 bg-white/90 px-4 py-2.5 text-sm text-ink shadow-[var(--glass-hi),0_12px_36px_rgb(21_67_96/0.22)] backdrop-blur-md"
          >
            {toastMsg.msg}
          </div>
        )}
      </div>
    </AppContext.Provider>
  );
}
