import type { SVGProps } from 'react';

/** Stroke icons from the v6 prototype (plus a few UI glyphs). Decorative by default. */
const PATHS = {
  dashboard: <><rect x="3" y="3" width="7" height="7" rx="1.5" /><rect x="14" y="3" width="7" height="7" rx="1.5" /><rect x="14" y="14" width="7" height="7" rx="1.5" /><rect x="3" y="14" width="7" height="7" rx="1.5" /></>,
  queue: <><path d="M4 6h10M4 12h10M4 18h6" /><circle cx="18.5" cy="16.5" r="3.5" /><path d="M18.5 15v1.7l1.1.8" /></>,
  patients: <><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" /></>,
  odontogram: <path d="M12 5.5c-1.6-1.4-3.4-2-5-1.5-2.4.8-3 3.6-2.2 6.3.6 2 .9 4.2 1.3 6.3.3 1.6.9 3.4 2 3.4s1.5-1.4 1.8-3c.3-1.5.8-2.5 2.1-2.5s1.8 1 2.1 2.5c.3 1.6.7 3 1.8 3s1.7-1.8 2-3.4c.4-2.1.7-4.3 1.3-6.3.8-2.7.2-5.5-2.2-6.3-1.6-.5-3.4.1-5 1.5z" />,
  appointments: <><rect x="3" y="4" width="18" height="18" rx="2" /><path d="M16 2v4M8 2v4M3 10h18" /></>,
  schedules: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
  treatments: <><rect x="8" y="2" width="8" height="4" rx="1" /><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" /><path d="M9 13h6M9 17h6" /></>,
  billing: <><rect x="2" y="5" width="20" height="14" rx="2" /><path d="M2 10h20" /></>,
  analytics: <><path d="M3 3v18h18" /><path d="M8 17v-5M13 17V8M18 17v-8" /></>,
  search: <><circle cx="11" cy="11" r="7" /><path d="M21 21l-4.3-4.3" /></>,
  menu: <path d="M4 7h16M4 12h16M4 17h16" />,
  close: <path d="M6 6l12 12M18 6L6 18" />,
  plus: <path d="M12 5v14M5 12h14" />,
  lock: <><rect x="5" y="11" width="14" height="10" rx="2" /><path d="M8 11V7a4 4 0 0 1 8 0v4" /></>,
  userPlus: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M19 8v6M22 11h-6" /></>,
  checkIn: <><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4" /><path d="M10 17l5-5-5-5M15 12H3" /></>,
  alert: <><path d="M12 3l9.5 17h-19z" /><path d="M12 10v4M12 17.5v.01" /></>,
  arrow: <path d="M5 12h14M13 6l6 6-6 6" />,
  external: <><path d="M14 4h6v6M20 4l-9 9" /><path d="M19 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h5" /></>,
} as const;

export type IconName = keyof typeof PATHS | 'spark';

export function Icon({ name, className = 'size-4', ...rest }: { name: IconName } & SVGProps<SVGSVGElement>) {
  if (name === 'spark') {
    return (
      <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden="true" focusable="false" {...rest}>
        <path d="M12 3l1.9 4.6L18.5 9.5l-4.6 1.9L12 16l-1.9-4.6L5.5 9.5l4.6-1.9z" />
      </svg>
    );
  }
  return (
    <svg
      viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth={1.8}
      strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false" {...rest}
    >
      {PATHS[name]}
    </svg>
  );
}

const TOOTH_OUTLINE =
  'M12 4.2C10.2 2.6 7.6 2 5.8 3.2 3.6 4.6 3.7 7.6 4.6 10.3c.7 2.1 1 4.5 1.4 6.7.3 1.7.9 3.5 2 3.5 1.2 0 1.5-1.6 1.8-3.2.3-1.5.8-2.7 2.2-2.7s1.9 1.2 2.2 2.7c.3 1.6.6 3.2 1.8 3.2 1.1 0 1.7-1.8 2-3.5.4-2.2.7-4.6 1.4-6.7.9-2.7 1-5.7-1.2-7.1-1.8-1.2-4.4-.6-6.2 1z';

/**
 * Brand mark: two interlaced tooth outlines (navy/white + aqua), a flat
 * version of the DentalFlow logo. Replace with the final SVG when available.
 */
export function BrandMark({ className = 'size-6', onDark = true }: { className?: string; onDark?: boolean }) {
  return (
    <svg viewBox="2 1.2 23 21.4" className={className} fill="none" strokeWidth={1.9} strokeLinejoin="round" aria-hidden="true" focusable="false">
      <path d={TOOTH_OUTLINE} transform="translate(2.6 .5)" stroke="#8FD3C4" />
      <path d={TOOTH_OUTLINE} stroke={onDark ? '#FFFFFF' : '#154360'} />
    </svg>
  );
}
