'use client';

import { useApp } from '@/components/providers/AppProvider';
import { Icon } from './Icon';

type Tone = 'ok' | 'warn' | 'bad' | 'info' | 'muted';

const TONE: Record<Tone, string> = {
  ok: 'text-ok border-ok/35 bg-ok/5',
  warn: 'text-warn border-warn/35 bg-warn/5',
  bad: 'text-bad border-bad/35 bg-bad/5',
  info: 'text-info border-info/35 bg-info/5',
  muted: 'text-ink-2 border-line bg-surface',
};
const DOT: Record<Tone, string> = { ok: 'bg-ok', warn: 'bg-warn', bad: 'bg-bad', info: 'bg-info', muted: 'bg-ink-3' };

const STATUS_TONE: Record<string, Tone> = {
  Confirmed: 'ok', Completed: 'ok', Done: 'ok', Paid: 'ok',
  Pending: 'warn', Waiting: 'warn',
  'In progress': 'info', 'In chair': 'info', 'Partially paid': 'info',
  Missed: 'bad', 'No-show': 'bad', Overdue: 'bad',
};

/** Status is always dot + text, never colour alone. */
export function Chip({ tone = 'muted', children }: { tone?: Tone; children: React.ReactNode }) {
  return (
    <span className={`inline-flex items-center gap-1.5 whitespace-nowrap rounded-full border px-2.5 py-0.5 text-xs font-medium ${TONE[tone]}`}>
      <i aria-hidden="true" className={`size-1.5 rounded-full ${DOT[tone]}`} />
      {children}
    </span>
  );
}

export function StatusChip({ status }: { status: string }) {
  const { term } = useApp();
  return <Chip tone={STATUS_TONE[status] ?? 'muted'}>{term(status)}</Chip>;
}

/** Allergy flag next to the patient's name — the dentist must see it before treating. */
export function AllergyBadge({ allergy }: { allergy: string | null }) {
  const { t, term } = useApp();
  if (!allergy) return null;
  const text = t('allergy', { a: term(allergy) });
  return (
    <span title={text} className="inline-flex items-center gap-1 whitespace-nowrap rounded-md bg-bad/10 px-1.5 py-0.5 text-xs font-semibold text-bad">
      <Icon name="alert" className="size-3.5" />
      {text}
    </span>
  );
}
