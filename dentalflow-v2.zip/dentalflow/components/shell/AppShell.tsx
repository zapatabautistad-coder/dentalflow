'use client';

import { usePathname } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { useApp } from '@/components/providers/AppProvider';
import { BrandMark, Icon } from '@/components/ui/Icon';
import { SidebarContent } from './Sidebar';
import { Topbar } from './Topbar';

export function AppShell({ children }: { children: React.ReactNode }) {
  const { t } = useApp();
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  const menuBtn = useRef<HTMLButtonElement>(null);
  const closeBtn = useRef<HTMLButtonElement>(null);

  // Close the drawer on navigation.
  useEffect(() => setOpen(false), [pathname]);

  // Drawer: Escape closes, focus moves in and back out.
  useEffect(() => {
    if (!open) return;
    const trigger = menuBtn.current;
    closeBtn.current?.focus();
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
      trigger?.focus();
    };
  }, [open]);

  return (
    <div className="min-h-dvh md:flex">
      <a href="#main" className="sr-only z-[70] rounded-lg bg-white px-3 py-2 text-sm font-semibold text-brand-ink focus:not-sr-only focus:fixed focus:left-3 focus:top-3">
        {t('skip')}
      </a>

      {/* Desktop sidebar */}
      <aside className="sidebar-grad sticky top-0 hidden h-dvh w-64 shrink-0 overflow-y-auto md:block">
        <SidebarContent />
      </aside>

      {/* Mobile header + drawer */}
      <div className="sidebar-grad on-brand flex items-center justify-between px-4 py-3 text-white md:hidden">
        <span className="flex items-center gap-2 font-bold">
          <BrandMark className="size-7" />
          DentalFlow
        </span>
        <button
          ref={menuBtn}
          type="button"
          onClick={() => setOpen(true)}
          aria-expanded={open}
          aria-controls="mobile-drawer"
          className="grid size-10 place-items-center rounded-lg border border-white/40 bg-white/15"
        >
          <Icon name="menu" className="size-5" />
          <span className="sr-only">{t('openMenu')}</span>
        </button>
      </div>
      {open && (
        <div className="fixed inset-0 z-50 md:hidden" role="dialog" aria-modal="true" aria-label={t('mainNav')} id="mobile-drawer">
          <button type="button" tabIndex={-1} aria-hidden="true" className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={() => setOpen(false)} />
          <div className="sidebar-grad absolute inset-y-0 left-0 w-[min(18rem,86vw)] overflow-y-auto">
            <div className="on-brand flex justify-end px-3 pt-3">
              <button ref={closeBtn} type="button" onClick={() => setOpen(false)} className="grid size-10 place-items-center rounded-lg border border-white/40 bg-white/15 text-white">
                <Icon name="close" className="size-5" />
                <span className="sr-only">{t('closeMenu')}</span>
              </button>
            </div>
            <SidebarContent onNavigate={() => setOpen(false)} />
          </div>
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar />
        <main id="main" tabIndex={-1} className="flex-1 px-4 py-5 focus:outline-none md:px-7 md:py-6">
          {children}
        </main>
      </div>
    </div>
  );
}
