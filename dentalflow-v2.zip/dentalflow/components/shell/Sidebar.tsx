'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useApp } from '@/components/providers/AppProvider';
import { BrandMark, Icon } from '@/components/ui/Icon';
import { COUNTRIES, COUNTRY_CODES, isCountryCode, l2 } from '@/lib/countries';
import { canView, moduleFromPath, MODULES, ROLE_KEYS } from '@/lib/roles';

/** Sidebar content — used by the desktop aside and the mobile drawer. */
export function SidebarContent({ onNavigate }: { onNavigate?: () => void }) {
  const { t, lang, setLang, clinic, role, roleName, testMode, setTestRole, setTestCountry, pending } = useApp();
  const current = moduleFromPath(usePathname());

  return (
    <div className="on-brand flex h-full flex-col gap-5 px-3.5 py-5 text-white">
      <div className="flex items-center gap-2.5 px-2">
        <BrandMark className="size-9 shrink-0" />
        <div className="min-w-0">
          <p className="text-[17px] font-bold leading-tight tracking-tight">DentalFlow</p>
          <p className="truncate text-xs text-white">{clinic.name}</p>
        </div>
      </div>

      <nav aria-label={t('mainNav')}>
        <ul className="space-y-1">
          {MODULES.map((m) => {
            const allowed = canView(role, m.key);
            const active = current === m.key;
            return (
              <li key={m.key}>
                <Link
                  href={m.href}
                  onClick={onNavigate}
                  aria-current={active ? 'page' : undefined}
                  className={[
                    'flex items-center gap-3 rounded-[10px] border-l-[3px] px-3 py-2.5 text-[13.5px] transition-colors',
                    active
                      ? 'border-aqua bg-white/15 font-semibold shadow-[var(--glass-hi),0_6px_18px_rgb(0_0_0/0.18)] backdrop-blur-md'
                      : 'border-transparent hover:bg-white/10',
                    allowed ? '' : 'opacity-75',
                  ].join(' ')}
                >
                  <Icon name={m.key} className={`size-[18px] shrink-0 ${active ? 'text-aqua' : ''}`} />
                  <span className="flex-1">{t(`nav_${m.key}`)}</span>
                  {!allowed && (
                    <>
                      <Icon name="lock" className="size-3.5 shrink-0" />
                      <span className="sr-only">({t('lockedNav', { r: roleName() })})</span>
                    </>
                  )}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="mt-auto space-y-4">
        <div className="space-y-1.5 px-1">
          <p id="lang-label" className="text-xs font-medium uppercase tracking-wider">{t('language')}</p>
          <div className="seg w-full" role="group" aria-labelledby="lang-label">
            {(['es', 'en'] as const).map((l) => (
              <button key={l} type="button" className="flex-1" aria-pressed={lang === l} onClick={() => setLang(l)}>
                {l.toUpperCase()}
              </button>
            ))}
          </div>
        </div>

        {testMode && (
          <section aria-labelledby="test-title" className="space-y-3 rounded-xl border border-dashed border-aqua/60 bg-white/5 p-3">
            <div>
              <h2 id="test-title" className="text-xs font-semibold uppercase tracking-wider">{t('testMode')}</h2>
              <p className="mt-0.5 text-xs leading-snug">{t('testModeHint')}</p>
            </div>
            <div className="space-y-1.5">
              <p id="role-label" className="text-xs font-medium">{t('role')}</p>
              <div className="seg w-full" role="group" aria-labelledby="role-label" aria-busy={pending}>
                {ROLE_KEYS.map((r) => (
                  <button key={r} type="button" className="flex-1 px-1.5 text-xs" aria-pressed={role === r} onClick={() => setTestRole(r)}>
                    {roleName(r)}
                  </button>
                ))}
              </div>
            </div>
            <label className="block space-y-1.5">
              <span className="text-xs font-medium">{t('country')}</span>
              <select
                value={clinic.country}
                onChange={(e) => isCountryCode(e.target.value) && setTestCountry(e.target.value)}
                className="w-full rounded-lg border border-white/35 bg-white/10 px-2.5 py-2 text-[13px] text-white"
              >
                {COUNTRY_CODES.map((c) => (
                  <option key={c} value={c} className="bg-white text-ink">{l2(lang, COUNTRIES[c].name)}</option>
                ))}
              </select>
            </label>
          </section>
        )}
      </div>
    </div>
  );
}
