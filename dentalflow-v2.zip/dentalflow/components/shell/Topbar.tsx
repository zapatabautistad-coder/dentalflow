'use client';

import Form from 'next/form';
import Link from 'next/link';
import { useApp } from '@/components/providers/AppProvider';
import { Icon } from '@/components/ui/Icon';
import { hoursOn } from '@/lib/clinic';
import { canView } from '@/lib/roles';
import { fmtHour, fmtLongDate, zonedParts } from '@/lib/time';

export function Topbar() {
  const { t, lang, clinic, user, role, roleName } = useApp();
  const now = new Date();
  const hours = hoursOn(clinic, zonedParts(now, clinic.timeZone).weekday);

  return (
    <header className="sticky top-0 z-30 border-b border-line bg-white/85 backdrop-blur-md">
      <div className="flex flex-wrap items-center gap-x-4 gap-y-3 px-4 py-3 md:px-7">
        <Form action="/patients" role="search" className="order-last w-full sm:order-none sm:w-auto sm:min-w-[260px] sm:flex-1 lg:max-w-md">
          <label htmlFor="global-search" className="sr-only">{t('searchLabel')}</label>
          <div className="flex items-center gap-2 rounded-[10px] border border-brand/40 bg-white px-3 py-2 focus-within:ring-2 focus-within:ring-brand">
            <Icon name="search" className="size-4 shrink-0 text-ink-3" />
            <input
              id="global-search"
              name="q"
              type="search"
              autoComplete="off"
              placeholder={t('searchPh')}
              className="w-full min-w-0 bg-transparent text-sm text-ink placeholder:text-ink-3 focus:outline-none"
            />
          </div>
        </Form>

        <div className="ml-auto hidden text-right md:block">
          <p className="text-sm font-semibold text-ink" suppressHydrationWarning>{fmtLongDate(now, lang, clinic.timeZone)}</p>
          <p className="text-xs text-ink-2">
            {hours ? t('clinicHours', { r: `${fmtHour(hours[0])}–${fmtHour(hours[1])}` }) : t('closedToday')}
          </p>
        </div>

        {canView(role, 'appointments') && (
          <Link href="/appointments?new=1" className="btn-glass ml-auto px-3.5 py-2 text-[13px] md:ml-0">
            <Icon name="plus" className="size-4" />
            {t('newAppt')}
          </Link>
        )}

        <div className="flex items-center gap-2.5 border-l border-line pl-4">
          <span className="grid size-9 shrink-0 place-items-center rounded-full bg-linear-to-br from-brand-2 to-brand text-xs font-semibold text-white">
            {user.initials}
          </span>
          <div className="hidden text-left leading-tight sm:block">
            <p className="text-[13px] font-semibold text-ink">{user.name ?? roleName()}</p>
            <p className="text-xs text-ink-2">{roleName(role)} · {clinic.name}</p>
          </div>
        </div>
      </div>
    </header>
  );
}
