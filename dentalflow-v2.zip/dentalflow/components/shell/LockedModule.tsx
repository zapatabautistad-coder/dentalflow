'use client';

import Link from 'next/link';
import { useApp } from '@/components/providers/AppProvider';
import { Icon } from '@/components/ui/Icon';
import { rolesWith, type ModuleKey } from '@/lib/roles';

/**
 * Shown when the signed-in role may not open a module. The permission check
 * itself runs on the server (in the page), so no module data reaches the browser.
 */
export function LockedModule({ moduleKey }: { moduleKey: ModuleKey }) {
  const { t, roleName } = useApp();
  const who = rolesWith(moduleKey).map((r) => roleName(r)).join(t('and'));
  return (
    <div className="card mx-auto mt-10 max-w-lg px-6 py-10 text-center">
      <Icon name="lock" className="mx-auto size-10 text-ink-3" />
      <h1 className="mt-3 text-xl font-bold tracking-tight text-ink">{t('lockedH', { m: t(`nav_${moduleKey}`) })}</h1>
      <p className="mt-2 text-sm text-ink-2">{t('lockedP', { r: roleName(), who })}</p>
      <Link href="/" className="btn-ghost mt-5 px-4 py-2 text-sm">{t('backDash')}</Link>
    </div>
  );
}
