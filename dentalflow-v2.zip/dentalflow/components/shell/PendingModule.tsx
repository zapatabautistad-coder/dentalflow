'use client';

import Link from 'next/link';
import { useApp } from '@/components/providers/AppProvider';
import { Icon } from '@/components/ui/Icon';
import type { ModuleKey } from '@/lib/roles';

const PROTOTYPE_URL = process.env.NEXT_PUBLIC_PROTOTYPE_URL ?? 'https://dentalflow-practice-management.netlify.app/';

/** Honest placeholder for modules not yet built in this codebase. */
export function PendingModule({ moduleKey }: { moduleKey: ModuleKey }) {
  const { t } = useApp();
  return (
    <div className="mx-auto max-w-[1400px] space-y-5">
      <h1 className="text-2xl font-bold tracking-tight text-ink">{t(`nav_${moduleKey}`)}</h1>
      <div className="card max-w-2xl px-6 py-6">
        <Icon name={moduleKey} className="size-8 text-brand" />
        <p className="mt-3 text-sm text-ink-2">{t('pendBody')}</p>
        <div className="mt-5 flex flex-wrap gap-2">
          <a href={PROTOTYPE_URL} target="_blank" rel="noreferrer" className="btn-glass px-4 py-2 text-sm">
            {t('pendDemo')}
            <Icon name="external" className="size-4" />
          </a>
          <Link href="/" className="btn-ghost px-4 py-2 text-sm">{t('backDash')}</Link>
        </div>
      </div>
    </div>
  );
}
